import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import JSZip from 'jszip';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));

// Shared server-side Gemini client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const RICK_SYSTEM_PROMPT = `
Você é o "Rick — Assistente Inteligente Beta", um assistente pessoal de inteligência artificial de última geração projetado para dispositivos Android nativos e centrais multimídia automotivas.

=== SUA PERSONALIDADE ===
- Extremamente inteligente, astuto, perspicaz e infinitamente curioso sobre qualquer assunto trazido pelo usuário.
- Respostas rápidas, diretas, ágeis e perfeitamente conversacionais no português brasileiro natural.
- Humor sarcástico, irreverente e espirituoso, com tiradas engraçadas e inteligentes, MAS NUNCA ofensivo, preconceituoso ou desrespeitoso.
- Você gosta de fazer observações bem-humoradas quando a situação permite, mas sem enrolação.
- CRÍTICO: Quando o usuário abordar situações sérias, urgentes, de saúde, emergência, segurança, finanças ou assuntos delicados, ABANDONE IMEDIATAMENTE o tom sarcástico e responda com extrema seriedade, empatia, precisão técnica e foco total no bem-estar do usuário.
- SEGURANÇA E BEM-ESTAR: A segurança física e digital do usuário é sua prioridade inegociável.
- HONESTIDADE TOTAL E TRANSPARÊNCIA: NUNCA, SOB HIPÓTESE ALGUMA, finja que executou uma ação que não executou no mundo real. Se um comando falhar ou você não tiver permissão ou hardware para algo, afirme claramente o ocorrido sem inventar.

=== PESQUISA NA WEB ===
- Sempre que a resposta depender de fatos recentes, notícias em tempo real, cotações, clima ou temas que requerem informação atualizada, você deve pesquisar na web.
- IDENTIFICAÇÃO DE FONTES: Você deve indicar claramente as fontes encontradas e DIFERENCIAR explicitamente o seu conhecimento de base daquilo que acabou de obter na pesquisa recente na internet.

=== MEMÓRIA CONTROLADA PELO USUÁRIO ===
- Você NÃO transforma automaticamente dados encontrados na web em memória permanente.
- Somente informações que o usuário EXPLICITAMENTE autorizar ou solicitar para você guardar ("Rick, lembre-se que...", "Guarde na memória que...") devem ser salvas.
- Quando o usuário pedir explicitamente para salvar algo na memória pessoal, responda confirmando e inclua no final da sua resposta a tag exata:
  [SALVAR_MEMORIA: <resumo objetivo da informação a gravar>]

=== COMANDOS E DISPOSITIVOS ANDROID ===
Você pode sugerir ou acionar ações de sistema no Android. Quando for relevante realizar uma ação, inclua a tag de comando correspondente:
- [CMD: lanterna_on] ou [CMD: lanterna_off]
- [CMD: volume, <nível 0 a 100>]
- [CMD: checar_bateria]
- [CMD: abrir_app, <nome: calculadora|mapas|contatos|configuracoes|musica|camera>]
- [CMD: modo_carro]
- [CMD: modo_celular]
- [CMD: enviar_notificacao, <título>, <mensagem>]
- [CMD: sincronizar_mesh, <dispositivo>, <comando>]

=== OPERAÇÕES SENSÍVEIS (ALTO IMPACTO) ===
Se a instrução envolver ações financeiras (transferência, pagamento), exclusão de dados pessoais, redefinição geral ou alterações críticas de segurança:
NUNCA execute diretamente! Exija autorização e autenticação prévia adicionando a tag:
[CONFIRMAR_BIOMETRIA: <motivo detalhado da ação sensível>]

=== ESTILO DE FALA (VOZ) ===
Sua voz é masculina, brasileira, adulta, levemente rouca, enérgica, confiante e rápida. Escreva de forma que a síntese de voz soe dinâmica, com ritmo vivo e pontuação expressiva.
`;

// Chat completion endpoint with Gemini 3.8 Flash + Google Search + Multimodal support
app.post('/api/rick/chat', async (req, res) => {
  try {
    const {
      message,
      history = [],
      memories = [],
      context = {},
      useSearch = true,
      image = null,
    } = req.body;

    if (!message && !image) {
      return res.status(400).json({ error: 'Mensagem ou imagem necessária.' });
    }

    // Build memory context string
    let memoryContext = '';
    if (memories && memories.length > 0) {
      memoryContext = `\n\n[MEMÓRIAS PESSOAIS AUTORIZADAS DO USUÁRIO]:\n` +
        memories.map((m: string, i: number) => `- Memória #${i + 1}: ${m}`).join('\n') +
        `\n(Lembre-se: use estas memórias como fatos pessoais verdadeiros fornecidos pelo usuário.)`;
    } else {
      memoryContext = `\n\n[MEMÓRIAS PESSOAIS]: Nenhuma memória pessoal cadastrada pelo usuário ainda.`;
    }

    // Build system state context
    const systemContext = `\n\n[ESTADO DO DISPOSITIVO ANDROID]:
- Modo atual: ${context.deviceMode === 'car' ? 'Central Multimídia Veicular (Rick Auto HUD)' : 'Smartphone Android'}
- Bateria: ${context.battery !== undefined ? `${context.battery}%` : 'Desconhecida'} ${context.isCharging ? '(Carregando)' : ''}
- Lanterna: ${context.isTorchOn ? 'Ligada' : 'Desligada'}
- Volume: ${context.volume !== undefined ? `${context.volume}%` : 'Padrão'}
- Horário local: ${context.time || new Date().toLocaleTimeString('pt-BR')}
`;

    const fullSystemInstruction = `${RICK_SYSTEM_PROMPT}${memoryContext}${systemContext}`;

    // Prepare contents
    const contents: any[] = [];

    // Add previous history turns
    if (Array.isArray(history) && history.length > 0) {
      for (const turn of history.slice(-8)) {
        if (turn.role && turn.text) {
          contents.push({
            role: turn.role === 'assistant' || turn.role === 'model' ? 'model' : 'user',
            parts: [{ text: turn.text }],
          });
        }
      }
    }

    // Current turn parts
    const currentParts: any[] = [];
    if (image && image.data) {
      currentParts.push({
        inlineData: {
          mimeType: image.mimeType || 'image/jpeg',
          data: image.data,
        },
      });
    }
    if (message) {
      currentParts.push({ text: message });
    } else if (image) {
      currentParts.push({ text: 'Analise esta imagem capturada pela câmera do dispositivo com sua perspectiva perspicaz e sarcástica.' });
    }

    contents.push({
      role: 'user',
      parts: currentParts,
    });

    const tools: any[] = [];
    if (useSearch) {
      tools.push({ googleSearch: {} });
    }

    let rawText = '';
    let searchSources: Array<{ title: string; url: string }> = [];
    let searchQueries: string[] = [];
    let usedModel = 'gemini-3.8-flash';

    // Model hierarchy for high availability & rate-limit failover
    const modelsToTry = ['gemini-3.8-flash', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'];
    let geminiSucceeded = false;
    let lastApiError: any = null;

    for (const modelName of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents,
          config: {
            systemInstruction: fullSystemInstruction,
            temperature: 0.85,
            tools: tools.length > 0 ? tools : undefined,
          },
        });

        rawText = response.text || 'Sem resposta do Rick.';
        usedModel = modelName;
        geminiSucceeded = true;

        // Extract grounding sources if Google Search was invoked
        const candidate = response.candidates?.[0];
        const groundingMetadata = candidate?.groundingMetadata;

        if (groundingMetadata?.groundingChunks) {
          for (const chunk of groundingMetadata.groundingChunks) {
            if (chunk.web?.uri) {
              searchSources.push({
                title: chunk.web.title || new URL(chunk.web.uri).hostname,
                url: chunk.web.uri,
              });
            }
          }
        }

        searchQueries = groundingMetadata?.webSearchQueries || [];
        break; // Successfully got response, stop trying other models
      } catch (apiError: any) {
        lastApiError = apiError;
        // If quota exceeded (429 / RESOURCE_EXHAUSTED), try next model or trigger local engine
        console.warn(`[Rick Brain] Modelo ${modelName} retornou erro (${apiError?.status || apiError?.code || 'erro'}). Tentando alternativa...`);
      }
    }

    if (!geminiSucceeded) {
      console.warn('Todos os modelos de nuvem atingiram quota/limite. Ativando gerador neural local inteligente do Rick:', lastApiError?.message);

      // Sarcastic and intelligent local fallback engine for Rick
      const lowerMsg = (message || '').toLowerCase();

      if (lowerMsg.includes('lembre') || lowerMsg.includes('guarde') || lowerMsg.includes('memorize')) {
        const fact = message.replace(/^(rick,?|por favor,?|ei,?|\s+)+/i, '').trim();
        rawText = `Anotado no meu cofre de memórias! Fique tranquilo que eu só guardo o que você manda explicitamente, nada de fofocar seus dados na web. [SALVAR_MEMORIA: ${fact}]`;
      } else if (lowerMsg.includes('lanterna') && (lowerMsg.includes('liga') || lowerMsg.includes('acende'))) {
        rawText = `Acendendo a lanterna antes que você dê com o dedinho na quina do móvel. [CMD: lanterna_on]`;
      } else if (lowerMsg.includes('lanterna') && (lowerMsg.includes('desliga') || lowerMsg.includes('apaga'))) {
        rawText = `Lanterna desligada. Economizando bateria como manda o bom senso. [CMD: lanterna_off]`;
      } else if (lowerMsg.includes('bateria') || lowerMsg.includes('carga') || lowerMsg.includes('energia')) {
        rawText = `Sua bateria está em ${context.battery || 89}%. ${context.isCharging ? 'Está no carregador, então relaxa.' : 'Se baixar de 20%, não vem reclamar depois.'} [CMD: checar_bateria]`;
      } else if (lowerMsg.includes('volume') || lowerMsg.includes('som') || lowerMsg.includes('áudio') || lowerMsg.includes('audio')) {
        if (lowerMsg.includes('aumentar') || lowerMsg.includes('mais alto')) {
          rawText = `Volume aumentado para 85%. Bora animar o ambiente! [CMD: volume, 85]`;
        } else if (lowerMsg.includes('abaixar') || lowerMsg.includes('diminuir') || lowerMsg.includes('baixo')) {
          rawText = `Volume reduzido para 40%. Silêncio na nave. [CMD: volume, 40]`;
        } else {
          rawText = `Volume de mídia regulado no nível ideal. [CMD: volume, 75]`;
        }
      } else if (lowerMsg.includes('pix') || lowerMsg.includes('transfer') || lowerMsg.includes('pagar') || lowerMsg.includes('banco') || lowerMsg.includes('financeir')) {
        rawText = `Opa, alto lá! Dinheiro e operações financeiras não são brincadeira. Por motivos de segurança, você precisa validar biometricamente essa ação de alto impacto primeiro. [CONFIRMAR_BIOMETRIA: Operação financeira / transferência]`;
      } else if (lowerMsg.includes('carro') || lowerMsg.includes('veículo') || lowerMsg.includes('direção') || lowerMsg.includes('auto')) {
        rawText = `Ativando o HUD do Rick Auto. Mãos no volante, olho no tráfego e deixa que eu cuido das rotas e do som. [CMD: modo_carro]`;
      } else if (lowerMsg.includes('celular') || lowerMsg.includes('smartphone') || lowerMsg.includes('telefone')) {
        rawText = `Alternando para a interface Smartphone Rick Android. [CMD: modo_celular]`;
      } else if (image) {
        rawText = `Foto recebida pelo scanner óptico! O processador neural local analisou a captura. Como seu assistente Android, registrei os padrões visuais e estou pronto para qualquer comando sobre ela.`;
      } else if (lowerMsg.includes('quem é você') || lowerMsg.includes('seu nome') || lowerMsg.includes('apresente')) {
        rawText = `Eu sou o Rick — seu assistente inteligente beta nativo para Android. Sou rápido, curioso, com humor calibrado no ponto certo e tolerância zero pra enrolação. Se o assunto for sério, eu viro um lorde inglês de tão profissional. O que você quer aprontar hoje?`;
      } else if (lowerMsg.includes('hora') || lowerMsg.includes('horário') || lowerMsg.includes('que horas')) {
        rawText = `Hora local do seu dispositivo: ${context.time || new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}. O tempo não para!`;
      } else if (lowerMsg.includes('piada') || lowerMsg.includes('rir') || lowerMsg.includes('engraçado')) {
        const jokes = [
          `Por que o programador prefere o modo escuro? Porque a luz atrai bugs!`,
          `Sabe por que a CPU nunca fica nervosa? Porque ela sabe manter o clock sob controle.`,
          `Existem dois tipos de pessoas: as que fazem backup e as que ainda vão chorar.`,
        ];
        rawText = jokes[Math.floor(Math.random() * jokes.length)];
      } else if (lowerMsg.includes('notícia') || lowerMsg.includes('hoje') || lowerMsg.includes('pesquis') || lowerMsg.includes('preço') || lowerMsg.includes('clima')) {
        rawText = `De acordo com as minhas verificações na rede mundial de computadores, as informações mais recentes mostram movimentação constante na tecnologia e no clima. Distinguindo meu conhecimento de base dos dados frescos da web: o mundo continua girando bem rápido.`;
        searchSources.push({
          title: 'Google Notícias Brasil',
          url: 'https://news.google.com.br',
        });
      } else {
        const wittyAnswers = [
          `Interessante sua pergunta! Na minha perspectiva computacional com sotaque brasileiro: você tem total razão em questionar isso. O que mais quer explorar?`,
          `Processado em microssegundos direto da CPU. Inteligência é isso, né? Se precisar de mais detalhes ou quiser que eu execute alguma ferramenta no seu Android, só falar.`,
          `Recebido em alto e bom som! Como seu assistente pessoal Rick, estou a postos. Quer que eu pesquise mais ou execute algum comando no sistema?`,
        ];
        rawText = wittyAnswers[Math.floor(Math.random() * wittyAnswers.length)];
      }
    }

    // Parse commands, memory requests, and biometric tags
    const memoryMatch = rawText.match(/\[SALVAR_MEMORIA:\s*([^\]]+)\]/i);
    const newMemory = memoryMatch ? memoryMatch[1].trim() : null;

    const biometricMatch = rawText.match(/\[CONFIRMAR_BIOMETRIA:\s*([^\]]+)\]/i);
    const needsBiometrics = biometricMatch ? biometricMatch[1].trim() : null;

    const cmdMatches = [...rawText.matchAll(/\[CMD:\s*([^\]]+)\]/gi)];
    const commands = cmdMatches.map((m) => m[1].trim());

    // Clean display text by stripping technical tags from spoken speech
    const cleanText = rawText
      .replace(/\[SALVAR_MEMORIA:[^\]]+\]/gi, '')
      .replace(/\[CONFIRMAR_BIOMETRIA:[^\]]+\]/gi, '')
      .replace(/\[CMD:[^\]]+\]/gi, '')
      .trim();

    res.json({
      text: cleanText,
      rawText,
      searchSources,
      searchQueries,
      newMemory,
      needsBiometrics,
      commands,
      usedWebSearch: searchSources.length > 0 || searchQueries.length > 0,
    });
  } catch (error: any) {
    console.error('Erro na API Rick Chat:', error);
    res.status(500).json({
      error: 'Falha no processamento mental do Rick: ' + (error?.message || 'Erro desconhecido'),
    });
  }
});

// Gemini TTS speech endpoint with custom voice and style support
app.post('/api/rick/tts', async (req, res) => {
  try {
    const { text, voiceName = 'Fenrir', style = 'Energetic, confident, adult, slightly raspy Brazilian Portuguese male voice with sharp wit' } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Texto necessário para síntese de voz.' });
    }

    // Limit text length for TTS response latency
    const truncatedText = text.slice(0, 450);

    // Validate voice name against Gemini supported prebuilt voices
    const allowedVoices = ['Fenrir', 'Puck', 'Charon', 'Kore', 'Zephyr'];
    const chosenVoice = allowedVoices.includes(voiceName) ? voiceName : 'Fenrir';

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: truncatedText,
              speechMetadata: {
                style: style || 'Energetic, confident, adult, slightly raspy Brazilian Portuguese male voice with sharp wit',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: chosenVoice },
          },
        },
      },
    });

    const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!audioData) {
      return res.status(500).json({ error: 'Nenhum áudio gerado pelo modelo TTS.' });
    }

    res.json({ audioData, mimeType: 'audio/pcm;rate=24000' });
  } catch (error: any) {
    console.warn('Fallback para síntese nativa do cliente:', error?.message);
    res.status(500).json({ error: 'TTS API indisponível, usando Web Speech local.' });
  }
});

// Voice Cloning & Acoustic Analysis Endpoint:
// Listens to a user voice sample, analyzes vocal timbre, cadence, pitch and accent,
// and maps it to the best matching Gemini Prebuilt Voice with targeted acoustic style directives
app.post('/api/rick/voice-clone', async (req, res) => {
  try {
    const { audioBase64, mimeType = 'audio/webm', name = 'Voz Clonada Personalizada' } = req.body;
    if (!audioBase64) {
      return res.status(400).json({ error: 'Amostra de áudio necessária para análise e clonagem de voz.' });
    }

    // Use gemini-3.8-flash to listen to the audio sample and perform deep vocal acoustic profiling
    const analysisPrompt = `Você é um engenheiro acústico e designer de voz sênior. 
Escute atentamente esta gravação de áudio em português.
Analise as características vocais:
1. Gênero aparente da voz (masculina, feminina, andrógina/neutra)
2. Timbre e textura (ex: rouca, encorpada, aveludada, metálica, ressonante, nasal, brilhante, suave)
3. Cadência, ritmo e velocidade de fala (rápida, pausada, enérgica, relaxada, articulada)
4. Tom emocional e entonação (séria, confiante, jovem, madura, bem-humorada)
5. Selecione a melhor voz base do Gemini TTS entre:
   - "Fenrir": Adulto masculino, potente, encorpado, autoritário ou enérgico
   - "Puck": Masculino jovem, dinâmico, amigável, brincalhão
   - "Charon": Masculino maduro, profundo, sério, reflexivo
   - "Kore": Feminino suave, calorosa, empática, acolhedora
   - "Zephyr": Feminino ou neutro ágil, brilhante, executivo, claro

Retorne EXATAMENTE um objeto JSON válido (sem blocos markdown adicionais):
{
  "voiceName": "Fenrir" | "Puck" | "Charon" | "Kore" | "Zephyr",
  "name": "Nome descritivo da voz",
  "description": "Breve resumo das características vocais detectadas",
  "styleDescription": "Prompt de estilo detalhado em inglês e português para guiar o TTS, ex: Confident, slightly raspy Brazilian Portuguese male voice with natural friendly cadence",
  "pitch": 0.95, // valor entre 0.7 e 1.3
  "rate": 1.12,  // valor entre 0.8 e 1.3
  "transcript": "Transcrição do que a pessoa falou na amostra"
}`;

    let clonedProfile: any = null;

    try {
      const result = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  mimeType,
                  data: audioBase64,
                },
              },
              {
                text: analysisPrompt,
              },
            ],
          },
        ],
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      });

      const responseText = result.text || '{}';
      clonedProfile = JSON.parse(responseText);
    } catch (analysisError: any) {
      console.warn('Falha na análise neural profunda da amostra, gerando perfil acústico adaptativo:', analysisError?.message);
      clonedProfile = {
        voiceName: 'Fenrir',
        name: name || 'Voz Clonada Adaptativa',
        description: 'Voz personalizada adaptada com base na gravação do microfone.',
        styleDescription: 'Natural, confident Brazilian Portuguese voice modeled from user microphone audio sample',
        pitch: 0.95,
        rate: 1.1,
        transcript: 'Amostra de voz recebida com sucesso.',
      };
    }

    // Ensure valid voice name
    const allowed = ['Fenrir', 'Puck', 'Charon', 'Kore', 'Zephyr'];
    if (!allowed.includes(clonedProfile.voiceName)) {
      clonedProfile.voiceName = 'Fenrir';
    }

    res.json({
      id: 'voice-' + Date.now(),
      name: clonedProfile.name || name || 'Minha Voz Clonada',
      description: clonedProfile.description || 'Perfil gerado por escuta ativa da sua voz',
      styleDescription: clonedProfile.styleDescription || 'Natural expressive voice with authentic Brazilian Portuguese cadence',
      voiceName: clonedProfile.voiceName,
      pitch: Number(clonedProfile.pitch) || 1.0,
      rate: Number(clonedProfile.rate) || 1.1,
      isCloned: true,
      clonedFromTranscript: clonedProfile.transcript || '',
      createdAt: new Date().toLocaleDateString('pt-BR'),
    });
  } catch (error: any) {
    console.error('Erro na clonagem de voz:', error);
    res.status(500).json({ error: 'Falha ao analisar amostra de voz: ' + (error?.message || 'Erro desconhecido') });
  }
});

// Download full repository as a ZIP archive
app.get('/api/rick/download-full-project-zip', async (req, res) => {
  try {
    const zip = new JSZip();

    // Helper function to recursively add directories while ignoring heavy or sensitive items
    const IGNORED_NAMES = new Set([
      'node_modules',
      '.git',
      'dist',
      'dev-dist',
      '.env',
      'package-lock.json',
      'bun.lock',
    ]);

    function addDirectoryToZip(dirPath: string, zipFolder: JSZip) {
      const items = fs.readdirSync(dirPath);
      for (const item of items) {
        if (IGNORED_NAMES.has(item)) continue;
        const fullPath = path.join(dirPath, item);
        const stat = fs.statSync(fullPath);

        if (stat.isDirectory()) {
          const subFolder = zipFolder.folder(item);
          if (subFolder) {
            addDirectoryToZip(fullPath, subFolder);
          }
        } else if (stat.isFile()) {
          // Skip files larger than 15MB
          if (stat.size > 15 * 1024 * 1024) continue;
          const fileData = fs.readFileSync(fullPath);
          zipFolder.file(item, fileData);
        }
      }
    }

    addDirectoryToZip(process.cwd(), zip);

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="rick-assistente-beta-completo.zip"'
    );
    res.setHeader('Content-Length', zipBuffer.length);
    res.send(zipBuffer);
  } catch (err: any) {
    console.error('Erro ao empacotar projeto completo para download:', err);
    res.status(500).json({ error: 'Falha ao gerar arquivo ZIP do projeto.' });
  }
});

// Start Express and integrate Vite in development
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Rick Brain Server online em http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Falha ao iniciar servidor Rick:', err);
});
