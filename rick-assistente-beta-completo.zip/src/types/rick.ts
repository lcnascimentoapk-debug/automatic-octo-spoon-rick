export interface SearchSource {
  title: string;
  url: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  searchSources?: SearchSource[];
  usedWebSearch?: boolean;
  searchQueries?: string[];
  commands?: string[];
  image?: {
    previewUrl: string;
    mimeType: string;
  };
  isSpoken?: boolean;
  newMemory?: string | null;
  needsBiometrics?: string | null;
}

export interface MemoryItem {
  id: string;
  content: string;
  createdAt: string;
  category?: 'pessoal' | 'preferencia' | 'trabalho' | 'veiculo' | 'geral';
  confirmedByUser: boolean;
}

export interface ConnectedDevice {
  id: string;
  name: string;
  type: 'phone' | 'tablet' | 'watch' | 'car' | 'tv';
  battery: number;
  isConnected: boolean;
  ip: string;
  lastSync: string;
}

export interface SystemState {
  battery: number;
  isCharging: boolean;
  isTorchOn: boolean;
  volume: number;
  notificationsEnabled: boolean;
  cameraPermission: 'prompt' | 'granted' | 'denied';
  micPermission: 'prompt' | 'granted' | 'denied';
  deviceMode: 'phone' | 'car' | 'mesh' | 'code';
  isOffline: boolean;
  forceOfflineMode: boolean;
}

export interface CarTelemetry {
  speed: number;
  fuel: number;
  gear: 'P' | 'R' | 'N' | 'D';
  temp: number;
  destination: string;
  eta: string;
  isPlayingMusic: boolean;
  currentTrack: string;
  artist: string;
}

export type PrebuiltGeminiVoice = 'Fenrir' | 'Puck' | 'Charon' | 'Kore' | 'Zephyr';

export interface VoiceProfile {
  id: string;
  name: string;
  description: string;
  styleDescription: string;
  voiceName: PrebuiltGeminiVoice;
  pitch: number;
  rate: number;
  isCloned?: boolean;
  sampleAudioUrl?: string;
  clonedFromTranscript?: string;
  createdAt?: string;
}

export interface VoiceSettings {
  activeProfileId: string;
  customProfiles: VoiceProfile[];
  pitch: number;
  rate: number;
  useNeuralTTS: boolean;
  autoSpeak: boolean;
}
