import { ChatMessage, MemoryItem, ConnectedDevice } from '../types/rick';

const STORAGE_KEYS = {
  MESSAGES: 'rick_offline_messages_v1',
  MEMORIES: 'rick_offline_memories_v1',
  DEVICES: 'rick_offline_devices_v1',
  OFFLINE_MODE_FLAG: 'rick_offline_force_flag_v1',
};

export class OfflineStorageManager {
  public static loadMessages(defaultMessages: ChatMessage[]): ChatMessage[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MESSAGES);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Erro ao carregar mensagens offline do localStorage:', e);
    }
    return defaultMessages;
  }

  public static saveMessages(messages: ChatMessage[]) {
    try {
      // Guarda até as 50 mensagens mais recentes para não inflar o storage
      const toSave = messages.slice(-50);
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(toSave));
    } catch (e) {
      console.warn('Erro ao salvar mensagens offline:', e);
    }
  }

  public static loadMemories(defaultMemories: MemoryItem[]): MemoryItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MEMORIES);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Erro ao carregar memórias offline:', e);
    }
    return defaultMemories;
  }

  public static saveMemories(memories: MemoryItem[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(memories));
    } catch (e) {
      console.warn('Erro ao salvar memórias offline:', e);
    }
  }

  public static loadDevices(defaultDevices: ConnectedDevice[]): ConnectedDevice[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.DEVICES);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Erro ao carregar mesh offline:', e);
    }
    return defaultDevices;
  }

  public static saveDevices(devices: ConnectedDevice[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.DEVICES, JSON.stringify(devices));
    } catch (e) {
      console.warn('Erro ao salvar mesh offline:', e);
    }
  }

  public static getForceOffline(): boolean {
    try {
      return localStorage.getItem(STORAGE_KEYS.OFFLINE_MODE_FLAG) === 'true';
    } catch {
      return false;
    }
  }

  public static setForceOffline(val: boolean) {
    try {
      localStorage.setItem(STORAGE_KEYS.OFFLINE_MODE_FLAG, val ? 'true' : 'false');
    } catch (e) {
      console.warn('Erro ao salvar flag offline:', e);
    }
  }
}
