import { ChatMessage, MemoryItem, SystemState } from '../types/rick';

export interface LocalBrainResponse {
  text: string;
  commands: string[];
  newMemory: string | null;
  needsBiometrics: string | null;
  isOfflineResponse: boolean;
}

export class RickOfflineBrain {
  /**
   * Responde localmente no navegador sem nenhuma requisição de rede.
   * Mantém o humor inteligente, sarcasmo afiado, seriedade para segurança
   * e total honestidade sobre a falta de conexão e status do hardware.
   */
  public processOffline(
    prompt: string,
    memories: MemoryItem[],
    systemState: Partial<SystemState>,
    hasImage?: boolean
  ): LocalBrainResponse {
    const raw = (prompt || '').trim();
    const lower = raw.toLowerCase();

    const commands: string[] = [];
    let newMemory: string | null = null;
    let needsBiometrics: string | null = null;
    let text = '';

    // 1. Lanterna
    if (lower.includes('lanterna') || lower.includes('flash')) {
      if (lower.includes('liga') || lower.includes('acende') || lower.includes('ativar')) {
        commands.push('lanterna_on');
        text = 'Lanterna ativada em modo offline! Sem tropeçar no escuro, campeão.';
      } else if (lower.includes('desliga') || lower.includes('apaga') || lower.includes('desativar')) {
        commands.push('lanterna_off');
        text = 'Lanterna desligada. Economizando bateria local com sucesso.';
      } else {
        text = `Sua lanterna está atualmente ${systemState.isTorchOn ? 'ligada' : 'desligada'}. Quer que eu alterne?`;
      }
    }
    // 2. Operações de alto impacto / sensíveis (Biometria)
    else if (
      lower.includes('pix') ||
      lower.includes('transfer') ||
      lower.includes('pagar') ||
      lower.includes('banco') ||
      lower.includes('dinheiro') ||
      lower.includes('senha') ||
      lower.includes('cartão') ||
      lower.includes('cartao')
    ) {
      needsBiometrics = 'Operação financeira / transação sensível';
      text =
        'Opa, alto lá! Dinheiro e operações bancárias exigem validação biométrica rigorosa. Além disso, transações externas dependem de rede para liquidação.';
    }
    // 3. Salvar Memória localmente no cofre
    else if (
      lower.includes('lembre-se') ||
      lower.includes('lembre') ||
      lower.includes('guarde') ||
      lower.includes('memorize') ||
      lower.includes('grave')
    ) {
      const cleanFact = raw
        .replace(/^(rick,?|por favor,?|ei,?|lembre-se que|lembre que|guarde que|memorize que|grave que|\s+)+/i, '')
        .trim();

      if (cleanFact.length > 2) {
        newMemory = cleanFact;
        text = `Fato memorizado com sucesso no cofre local offline: "${cleanFact}". Quando a rede voltar, continuará são e salvo!`;
      } else {
        text = 'Diga o que você quer que eu guarde no seu cofre de memórias.';
      }
    }
    // 4. Consultar Memórias no Cofre
    else if (
      lower.includes('minhas memórias') ||
      lower.includes('o que você sabe sobre mim') ||
      lower.includes('lembra de mim') ||
      lower.includes('meus dados')
    ) {
      if (memories.length === 0) {
        text = 'Meu cofre local está vazio no momento. Você ainda não me autorizou a gravar nenhuma memória pessoal.';
      } else {
        const list = memories.map((m, i) => `${i + 1}. ${m.content}`).join('\n');
        text = `Aqui estão as memórias autorizadas no meu cofre offline:\n${list}\n\nTotal controle seu: você pode editar ou apagar qualquer uma na central de memórias.`;
      }
    }
    // 5. Bateria e Telemetria
    else if (lower.includes('bateria') || lower.includes('carga') || lower.includes('energia')) {
      const bat = systemState.battery ?? 85;
      const chg = systemState.isCharging;
      text = `Telemetria de energia offline: Bateria em ${bat}%. ${
        chg ? 'Conectado ao carregador.' : bat < 20 ? 'Alerta: bateria baixa! Plugue no carregador.' : 'Nível seguro de autonomia.'
      }`;
    }
    // 6. Volume
    else if (lower.includes('volume') || lower.includes('som') || lower.includes('áudio') || lower.includes('audio')) {
      if (lower.includes('aumentar') || lower.includes('mais alto')) {
        const newVol = Math.min(100, (systemState.volume ?? 75) + 15);
        commands.push(`volume,${newVol}`);
        text = `Volume aumentado para ${newVol}%.`;
      } else if (lower.includes('abaixar') || lower.includes('diminuir') || lower.includes('mais baixo')) {
        const newVol = Math.max(0, (systemState.volume ?? 75) - 15);
        commands.push(`volume,${newVol}`);
        text = `Volume reduzido para ${newVol}%.`;
      } else {
        text = `Volume de mídia atual: ${systemState.volume ?? 75}%.`;
      }
    }
    // 7. Modo Carro / HUD Veicular
    else if (lower.includes('carro') || lower.includes('veículo') || lower.includes('direção') || lower.includes('auto')) {
      commands.push('modo_carro');
      text = 'Alternando para o HUD do Rick Auto! Mesmo offline, seu velocímetro, controle de música e voz estão ativos.';
    }
    // 8. Modo Celular / Smartphone
    else if (lower.includes('celular') || lower.includes('smartphone') || lower.includes('telefone')) {
      commands.push('modo_celular');
      text = 'Alternando para a interface Smartphone Rick.';
    }
    // 9. Quem é você / Apresentação
    else if (lower.includes('quem é você') || lower.includes('seu nome') || lower.includes('apresente')) {
      text =
        'Eu sou o Rick — seu assistente inteligente beta! No momento estou operando no MODO OFFLINE LOCAL (Edge Computing). Todas as minhas rotinas de voz, lanterna, memória e hardware continuam a todo vapor sem precisar de um byte de internet.';
    }
    // 10. Perguntas sobre internet / pesquisa web offline (Honestidade)
    else if (
      lower.includes('notícia') ||
      lower.includes('hoje') ||
      lower.includes('cotação') ||
      lower.includes('dólar') ||
      lower.includes('preço') ||
      lower.includes('tempo em') ||
      lower.includes('clima em') ||
      lower.includes('resultado do jogo')
    ) {
      text =
        'Honestidade primeiro: estou no Modo Offline Completo e não consigo consultar a web agora para checar dados em tempo real. Assim que a conexão for restabelecida ou você desativar o modo offline, eu busco isso no Google Search!';
    }
    // 11. Análise de Imagem offline
    else if (hasImage) {
      text =
        'Foto recebida no sensor! Em modo offline nativo, os pixels foram armazenados no buffer local. Análise neural visual profunda requer conexão com o Gemini Brain, mas os dados estão salvos no cache do dispositivo.';
    }
    // 12. Diálogo geral com sarcasmo e inteligência calibrada
    else if (lower.includes('olá') || lower.includes('oi') || lower.includes('e aí') || lower.includes('fala')) {
      text =
        'E aí! Rick na escuta, totalmente operacional em modo offline local. Pode pedir pra acender lanterna, guardar memórias, checar bateria ou mudar pro modo veicular.';
    } else if (lower.includes('obrigado') || lower.includes('valeu') || lower.includes('agradeço')) {
      text = 'Disponha! Assistente que é assistente não te deixa na mão nem no meio do deserto sem sinal.';
    } else if (lower.includes('piada') || lower.includes('rir') || lower.includes('engraçado')) {
      const jokes = [
        'Por que o desenvolvedor foi ao médico? Porque ele não conseguia pegar um "catch" e estava com vazamento de memória!',
        'Existem 10 tipos de pessoas no mundo: as que entendem binário e as que não entendem. E as que não esperavam uma piada em base 3.',
        'Sabe por que eu adoro o modo offline? Zero anúncios, zero cookies chatos e velocidade da luz direto da sua CPU.',
      ];
      text = jokes[Math.floor(Math.random() * jokes.length)];
    } else if (lower.includes('hora') || lower.includes('horário') || lower.includes('que horas')) {
      text = `Hora local do dispositivo: ${new Date().toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit',
      })}.`;
    } else {
      const offlineAnswers = [
        `Comando processado pelo motor local do Rick. Estou operando sem internet com latência zero. O que mais manda?`,
        `Entendido perfeitamente. Como estamos offline, mantenho tudo rodando direto no chip do seu dispositivo. Quer testar a lanterna ou o cofre de memórias?`,
        `Recebido! Memória rápida, sarcasmo intacto e zero dependência de servidor externo. Se precisar de uma ação de hardware, é só falar.`,
      ];
      text = offlineAnswers[Math.floor(Math.random() * offlineAnswers.length)];
    }

    return {
      text,
      commands,
      newMemory,
      needsBiometrics,
      isOfflineResponse: true,
    };
  }
}

export const rickOfflineBrain = new RickOfflineBrain();
