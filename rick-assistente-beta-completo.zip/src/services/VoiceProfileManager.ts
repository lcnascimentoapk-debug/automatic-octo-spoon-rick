import { VoiceProfile, PrebuiltGeminiVoice, VoiceSettings } from '../types/rick';

export const DEFAULT_VOICE_PROFILES: VoiceProfile[] = [
  {
    id: 'rick-classic',
    name: 'Rick Original (Fenrir)',
    description: 'Voz masculina adulta, ligeiramente rouca, enérgica, rápida e com sarcasmo afiado.',
    styleDescription: 'Energetic, confident, adult, slightly raspy Brazilian Portuguese male voice with sharp wit and fast cadence',
    voiceName: 'Fenrir',
    pitch: 0.92,
    rate: 1.15,
    isCloned: false,
  },
  {
    id: 'rick-dynamic',
    name: 'Rick Jovem & Dinâmico (Puck)',
    description: 'Voz masculina jovem, ágil, descontraída e bem-humorada.',
    styleDescription: 'Dynamic, youthful, witty and lively Brazilian Portuguese male voice with conversational warmth',
    voiceName: 'Puck',
    pitch: 1.05,
    rate: 1.18,
    isCloned: false,
  },
  {
    id: 'rick-deep',
    name: 'Rick Noturno & Profundo (Charon)',
    description: 'Voz masculina madura, profunda, ressonante, elegante e serena.',
    styleDescription: 'Deep, resonant, mature, cinematic and reassuring Brazilian Portuguese voice with composed authority',
    voiceName: 'Charon',
    pitch: 0.85,
    rate: 1.02,
    isCloned: false,
  },
  {
    id: 'rick-empathic',
    name: 'Rick Acolhedor (Kore)',
    description: 'Voz feminina/empática suave, clara, calorosa e compreensiva.',
    styleDescription: 'Warm, clear, empathetic, soothing Brazilian Portuguese female voice with gentle articulation',
    voiceName: 'Kore',
    pitch: 1.0,
    rate: 1.08,
    isCloned: false,
  },
  {
    id: 'rick-executive',
    name: 'Rick Futurista & Ágil (Zephyr)',
    description: 'Voz brilhante, precisa, executiva e de alta definição tecnológica.',
    styleDescription: 'Crisp, articulate, futuristic, executive and balanced voice with modern clarity',
    voiceName: 'Zephyr',
    pitch: 1.02,
    rate: 1.14,
    isCloned: false,
  },
];

const STORAGE_KEY_VOICE_SETTINGS = 'rick_voice_settings_v1';

export class VoiceProfileManager {
  public static loadSettings(): VoiceSettings {
    if (typeof window === 'undefined') {
      return {
        activeProfileId: 'rick-classic',
        customProfiles: [],
        pitch: 0.92,
        rate: 1.14,
        useNeuralTTS: true,
        autoSpeak: true,
      };
    }

    try {
      const stored = localStorage.getItem(STORAGE_KEY_VOICE_SETTINGS);
      if (stored) {
        const parsed = JSON.parse(stored);
        return {
          activeProfileId: parsed.activeProfileId || 'rick-classic',
          customProfiles: parsed.customProfiles || [],
          pitch: typeof parsed.pitch === 'number' ? parsed.pitch : 0.92,
          rate: typeof parsed.rate === 'number' ? parsed.rate : 1.14,
          useNeuralTTS: parsed.useNeuralTTS !== undefined ? parsed.useNeuralTTS : true,
          autoSpeak: parsed.autoSpeak !== undefined ? parsed.autoSpeak : true,
        };
      }
    } catch (e) {
      console.warn('Erro ao carregar configurações de voz:', e);
    }

    return {
      activeProfileId: 'rick-classic',
      customProfiles: [],
      pitch: 0.92,
      rate: 1.14,
      useNeuralTTS: true,
      autoSpeak: true,
    };
  }

  public static saveSettings(settings: VoiceSettings): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY_VOICE_SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.warn('Erro ao salvar configurações de voz:', e);
    }
  }

  public static getAllProfiles(settings: VoiceSettings): VoiceProfile[] {
    return [...DEFAULT_VOICE_PROFILES, ...settings.customProfiles];
  }

  public static getActiveProfile(settings: VoiceSettings): VoiceProfile {
    const all = this.getAllProfiles(settings);
    return all.find((p) => p.id === settings.activeProfileId) || DEFAULT_VOICE_PROFILES[0];
  }
}
