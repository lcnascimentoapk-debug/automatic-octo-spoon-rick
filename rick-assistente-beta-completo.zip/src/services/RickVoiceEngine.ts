/**
 * Rick Voice Engine - Customizable Brazilian Portuguese Synthesis & Speech Recognition
 *
 * Supports:
 * - High-Fidelity Gemini Neural Voice Models ('gemini-3.8-flash-lite-tts') with custom styles & personas
 * - Cloned Voice Synthesis via active audio sample listener
 * - Web Speech API local fallback with custom pitch & rate
 */

import { VoiceProfile, VoiceSettings } from '../types/rick';
import { VoiceProfileManager } from './VoiceProfileManager';

export class RickVoiceEngine {
  private synth: SpeechSynthesis | null = null;
  private recognition: any = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private currentAudioElement: HTMLAudioElement | null = null;
  private audioContext: AudioContext | null = null;
  private isListening: boolean = false;
  private isSpeaking: boolean = false;
  private onSpeechResultCallback: ((text: string) => void) | null = null;
  private onListeningStateCallback: ((isListening: boolean) => void) | null = null;
  private onSpeakingStateCallback: ((isSpeaking: boolean) => void) | null = null;
  private voiceSettings: VoiceSettings;

  constructor() {
    this.voiceSettings = VoiceProfileManager.loadSettings();

    if (typeof window !== 'undefined') {
      if ('speechSynthesis' in window) {
        this.synth = window.speechSynthesis;
      }
      this.initRecognition();
    }
  }

  public getSettings(): VoiceSettings {
    return this.voiceSettings;
  }

  public updateSettings(newSettings: VoiceSettings) {
    this.voiceSettings = newSettings;
    VoiceProfileManager.saveSettings(newSettings);
  }

  private initRecognition() {
    if (typeof window === 'undefined') return;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.lang = 'pt-BR';
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.maxAlternatives = 1;

      this.recognition.onstart = () => {
        this.isListening = true;
        this.onListeningStateCallback?.(true);
        this.playBeep(880, 0.08, 'sine'); // Futuristic start listening chirp
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.onListeningStateCallback?.(false);
      };

      this.recognition.onresult = (event: any) => {
        const transcript = event.results[0]?.[0]?.transcript;
        if (transcript && this.onSpeechResultCallback) {
          this.onSpeechResultCallback(transcript);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        this.isListening = false;
        this.onListeningStateCallback?.(false);
      };
    }
  }

  // Find best matching Brazilian Portuguese browser voice
  private getBestVoice(): SpeechSynthesisVoice | null {
    if (!this.synth) return null;
    const voices = this.synth.getVoices();

    const activeProfile = VoiceProfileManager.getActiveProfile(this.voiceSettings);
    const prefersFemale = activeProfile.voiceName === 'Kore';

    if (prefersFemale) {
      const femalePt = voices.find(
        (v) =>
          (v.lang === 'pt-BR' || v.lang.startsWith('pt')) &&
          (v.name.toLowerCase().includes('maria') ||
            v.name.toLowerCase().includes('leticia') ||
            v.name.toLowerCase().includes('francisca') ||
            v.name.toLowerCase().includes('female') ||
            v.name.toLowerCase().includes('mulher'))
      );
      if (femalePt) return femalePt;
    } else {
      const malePtBr = voices.find(
        (v) =>
          (v.lang === 'pt-BR' || v.lang.startsWith('pt')) &&
          (v.name.toLowerCase().includes('daniel') ||
            v.name.toLowerCase().includes('antonio') ||
            v.name.toLowerCase().includes('felipe') ||
            v.name.toLowerCase().includes('thiago') ||
            v.name.toLowerCase().includes('homem') ||
            v.name.toLowerCase().includes('male'))
      );
      if (malePtBr) return malePtBr;
    }

    const ptBr = voices.find(
      (v) =>
        v.lang === 'pt-BR' ||
        v.lang === 'pt_BR' ||
        v.name.toLowerCase().includes('brasil') ||
        v.name.toLowerCase().includes('brazil')
    );
    if (ptBr) return ptBr;

    const anyPt = voices.find((v) => v.lang.startsWith('pt'));
    if (anyPt) return anyPt;

    return null;
  }

  /**
   * Helper to decode and play raw PCM 24000Hz audio from Gemini TTS
   */
  private playPcmBase64(base64Data: string, sampleRate = 24000): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioCtx) {
          reject(new Error('AudioContext indisponível'));
          return;
        }

        if (!this.audioContext) {
          this.audioContext = new AudioCtx();
        }

        if (this.audioContext.state === 'suspended') {
          this.audioContext.resume();
        }

        const binary = atob(base64Data);
        const len = binary.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binary.charCodeAt(i);
        }

        // Gemini PCM 24000Hz is signed 16-bit little endian
        const int16Array = new Int16Array(bytes.buffer);
        const float32Array = new Float32Array(int16Array.length);
        for (let i = 0; i < int16Array.length; i++) {
          float32Array[i] = int16Array[i] / 32768.0;
        }

        const buffer = this.audioContext.createBuffer(1, float32Array.length, sampleRate);
        buffer.getChannelData(0).set(float32Array);

        const source = this.audioContext.createBufferSource();
        source.buffer = buffer;
        source.connect(this.audioContext.destination);

        source.onended = () => {
          this.isSpeaking = false;
          this.onSpeakingStateCallback?.(false);
          resolve();
        };

        this.isSpeaking = true;
        this.onSpeakingStateCallback?.(true);
        source.start(0);
      } catch (err) {
        reject(err);
      }
    });
  }

  /**
   * Speak text with the active voice profile (Neural Gemini TTS or Web Speech fallback)
   */
  public async speak(
    text: string,
    onStart?: () => void,
    onEnd?: () => void
  ): Promise<void> {
    this.stopSpeaking();

    // Clean text from symbols/emojis
    const cleanedText = text
      .replace(/[*_#`~>\[\]]/g, ' ')
      .replace(/\b(https?:\/\/[^\s]+)/g, 'link da fonte')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanedText) return;

    const activeProfile = VoiceProfileManager.getActiveProfile(this.voiceSettings);

    // Attempt 1: High Fidelity Neural TTS via Gemini Server API if enabled
    if (this.voiceSettings.useNeuralTTS && typeof navigator !== 'undefined' && navigator.onLine) {
      try {
        onStart?.();
        const response = await fetch('/api/rick/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: cleanedText,
            voiceName: activeProfile.voiceName,
            style: activeProfile.styleDescription,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          if (data.audioData) {
            await this.playPcmBase64(data.audioData, 24000);
            onEnd?.();
            return;
          }
        }
      } catch (neuralError) {
        console.warn('Neural TTS indisponível no momento, chaveando para síntese local:', neuralError);
      }
    }

    // Attempt 2: Local Web Speech API with custom pitch & rate
    return this.speakLocalBrowser(cleanedText, activeProfile, onStart, onEnd);
  }

  /**
   * Local browser fallback with custom pitch and rate
   */
  private speakLocalBrowser(
    cleanedText: string,
    profile: VoiceProfile,
    onStart?: () => void,
    onEnd?: () => void
  ): Promise<void> {
    return new Promise((resolve) => {
      if (!this.synth) {
        resolve();
        return;
      }

      const utterance = new SpeechSynthesisUtterance(cleanedText);
      const voice = this.getBestVoice();
      if (voice) {
        utterance.voice = voice;
      }

      utterance.lang = 'pt-BR';
      utterance.rate = this.voiceSettings.rate || profile.rate || 1.14;
      utterance.pitch = this.voiceSettings.pitch || profile.pitch || 0.92;
      utterance.volume = 1.0;

      utterance.onstart = () => {
        this.isSpeaking = true;
        this.onSpeakingStateCallback?.(true);
        onStart?.();
      };

      utterance.onend = () => {
        this.isSpeaking = false;
        this.onSpeakingStateCallback?.(false);
        this.currentUtterance = null;
        onEnd?.();
        resolve();
      };

      utterance.onerror = (e) => {
        console.warn('Speech synthesis error:', e);
        this.isSpeaking = false;
        this.onSpeakingStateCallback?.(false);
        this.currentUtterance = null;
        onEnd?.();
        resolve();
      };

      this.currentUtterance = utterance;
      this.synth.speak(utterance);
    });
  }

  public stopSpeaking() {
    if (this.synth) {
      this.synth.cancel();
    }
    if (this.audioContext && this.audioContext.state === 'running') {
      try {
        this.audioContext.suspend();
      } catch {}
    }
    if (this.currentAudioElement) {
      this.currentAudioElement.pause();
      this.currentAudioElement = null;
    }
    this.isSpeaking = false;
    this.currentUtterance = null;
    this.onSpeakingStateCallback?.(false);
  }

  public startListening(onResult: (text: string) => void) {
    if (!this.recognition) {
      alert('Reconhecimento de voz não suportado neste navegador. Use a digitação de texto.');
      return;
    }
    this.onSpeechResultCallback = onResult;
    try {
      this.stopSpeaking();
      this.recognition.start();
    } catch (e) {
      console.warn('Error starting recognition:', e);
    }
  }

  public stopListening() {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
      this.isListening = false;
      this.onListeningStateCallback?.(false);
    }
  }

  public setCallbacks(listeners: {
    onListeningChange?: (val: boolean) => void;
    onSpeakingChange?: (val: boolean) => void;
  }) {
    if (listeners.onListeningChange) {
      this.onListeningStateCallback = listeners.onListeningChange;
    }
    if (listeners.onSpeakingChange) {
      this.onSpeakingStateCallback = listeners.onSpeakingChange;
    }
  }

  /**
   * Futuristic acoustic feedback sound
   */
  private playBeep(freq: number, duration: number, type: OscillatorType = 'sine') {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      if (!this.audioContext) {
        this.audioContext = new AudioCtx();
      }
      if (this.audioContext.state === 'suspended') {
        this.audioContext.resume();
      }

      const osc = this.audioContext.createOscillator();
      const gain = this.audioContext.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.audioContext.currentTime);

      gain.gain.setValueAtTime(0.06, this.audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.audioContext.destination);

      osc.start();
      osc.stop(this.audioContext.currentTime + duration);
    } catch {
      // AudioContext requires user gesture on first load
    }
  }
}

export const rickVoice = new RickVoiceEngine();
