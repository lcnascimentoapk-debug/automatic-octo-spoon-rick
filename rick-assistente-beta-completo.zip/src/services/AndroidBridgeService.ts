import { ConnectedDevice } from '../types/rick';

export class AndroidBridgeService {
  private torchTrack: MediaStreamTrack | null = null;
  private isTorchActive: boolean = false;

  /**
   * Monitor real battery status if supported by Android WebView / Chromium
   */
  public async initBattery(onUpdate: (battery: number, isCharging: boolean) => void) {
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      try {
        const battery: any = await (navigator as any).getBattery();
        const update = () => {
          onUpdate(Math.round(battery.level * 100), battery.charging);
        };
        update();
        battery.addEventListener('levelchange', update);
        battery.addEventListener('chargingchange', update);
      } catch (e) {
        console.warn('Battery API not available:', e);
      }
    }
  }

  /**
   * Toggle Hardware Torch / Flashlight
   * Rick prioritizes honesty: if hardware is unavailable, reports honestly!
   */
  public async toggleTorch(targetState?: boolean): Promise<{ success: boolean; message: string; state: boolean }> {
    const desired = targetState !== undefined ? targetState : !this.isTorchActive;

    try {
      if (!this.torchTrack) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        const track = stream.getVideoTracks()[0];
        const capabilities: any = track.getCapabilities?.();

        if (capabilities && 'torch' in capabilities) {
          this.torchTrack = track;
        } else {
          // Hardware doesn't support torch or running in browser simulator
          this.isTorchActive = desired;
          return {
            success: true,
            message: desired
              ? 'Lanterna virtual ativada na tela (hardware físico de flash sem suporte direto na sessão).'
              : 'Lanterna virtual desativada.',
            state: this.isTorchActive,
          };
        }
      }

      await (this.torchTrack as any).applyConstraints({
        advanced: [{ torch: desired }],
      });
      this.isTorchActive = desired;

      return {
        success: true,
        message: desired ? 'Lanterna traseira ligada.' : 'Lanterna traseira desligada.',
        state: this.isTorchActive,
      };
    } catch (err: any) {
      // Fallback with honest transparency
      this.isTorchActive = desired;
      return {
        success: false,
        message: `Não foi possível acessar o flash físico (${err?.message || 'permissão negada'}). Ativando lanterna visual de tela.`,
        state: this.isTorchActive,
      };
    }
  }

  /**
   * Send Native Android Notification
   */
  public async sendNotification(title: string, body: string): Promise<boolean> {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return false;
    }

    try {
      if (Notification.permission === 'granted') {
        new Notification(title, {
          body,
          icon: '/favicon.ico',
        });
        return true;
      } else if (Notification.permission !== 'denied') {
        const perm = await Notification.requestPermission();
        if (perm === 'granted') {
          new Notification(title, { body, icon: '/favicon.ico' });
          return true;
        }
      }
      return false;
    } catch (e) {
      console.warn('Falha ao emitir notificação Android:', e);
      return false;
    }
  }

  /**
   * Mock default Android devices for the inter-device mesh
   */
  public getDefaultMeshDevices(): ConnectedDevice[] {
    return [
      {
        id: 'tab-ultra-01',
        name: 'Samsung Galaxy Tab S9+',
        type: 'tablet',
        battery: 84,
        isConnected: true,
        ip: '192.168.1.14',
        lastSync: 'Agora',
      },
      {
        id: 'rick-watch-02',
        name: 'Rick Watch Pro (WearOS 5)',
        type: 'watch',
        battery: 62,
        isConnected: true,
        ip: '192.168.1.28',
        lastSync: 'Há 1 min',
      },
      {
        id: 'car-hud-03',
        name: 'Central Multimídia Veicular Android Auto',
        type: 'car',
        battery: 100,
        isConnected: true,
        ip: '192.168.1.88',
        lastSync: 'Ativa no Painel',
      },
      {
        id: 'smart-tv-04',
        name: 'Android TV Sala de Estar',
        type: 'tv',
        battery: 100,
        isConnected: false,
        ip: '192.168.1.102',
        lastSync: 'Ontem',
      },
    ];
  }
}

export const androidBridge = new AndroidBridgeService();
