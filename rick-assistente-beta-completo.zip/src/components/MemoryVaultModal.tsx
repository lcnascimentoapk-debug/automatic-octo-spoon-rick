import React, { useState } from 'react';
import { Database, Plus, Trash2, ShieldCheck, X, Search, AlertCircle, Info } from 'lucide-react';
import { MemoryItem } from '../types/rick';

interface MemoryVaultModalProps {
  isOpen: boolean;
  onClose: () => void;
  memories: MemoryItem[];
  onAddMemory: (content: string, category?: string) => void;
  onDeleteMemory: (id: string) => void;
  onRequestClearAll: () => void;
}

export const MemoryVaultModal: React.FC<MemoryVaultModalProps> = ({
  isOpen,
  onClose,
  memories,
  onAddMemory,
  onDeleteMemory,
  onRequestClearAll,
}) => {
  const [newContent, setNewContent] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'pessoal' | 'preferencia' | 'veiculo' | 'geral'>('pessoal');

  if (!isOpen) return null;

  const filteredMemories = memories.filter((m) =>
    m.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;
    onAddMemory(newContent.trim(), selectedCategory);
    setNewContent('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-cyan-500/30 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950 border-b border-cyan-950/80">
          <div className="flex items-center space-x-2 text-cyan-400">
            <Database className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="font-semibold text-sm text-slate-100 font-mono tracking-wide">
                COFRE DE MEMÓRIA PESSOAL DO RICK
              </h3>
              <p className="text-[11px] text-cyan-400/80">Controle 100% nas mãos do usuário</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Security / Privacy policy banner */}
        <div className="bg-cyan-950/40 border-b border-cyan-500/20 px-4 py-2.5 flex items-start gap-2.5 text-xs text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
          <p className="leading-snug text-[11px]">
            <strong className="text-cyan-300">Política de Privacidade:</strong> Rick{' '}
            <span className="text-amber-300 font-medium">nunca</span> transforma pesquisas da web em memórias permanentes. Somente fatos autorizados expressamente por você são gravados aqui.
          </p>
        </div>

        {/* Search & Stats */}
        <div className="p-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Buscar em memórias salvas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 focus:border-cyan-400 rounded-xl text-xs text-slate-200 focus:outline-none transition"
            />
          </div>

          {/* Add new memory input */}
          <form onSubmit={handleSubmit} className="space-y-2 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Ex: 'Meu café favorito é espresso sem açúcar' ou 'Placa do carro ABC-1234'"
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-900 border border-slate-700 focus:border-cyan-400 rounded-lg text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={!newContent.trim()}
                className="px-3.5 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                Gravar
              </button>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              <span className="text-slate-500">Categoria:</span>
              {(['pessoal', 'preferencia', 'veiculo', 'geral'] as const).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2 py-0.5 rounded capitalize transition ${
                    selectedCategory === cat
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-semibold'
                      : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </form>
        </div>

        {/* Memory Items List */}
        <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2.5">
          {filteredMemories.length === 0 ? (
            <div className="py-10 text-center text-slate-500 space-y-2">
              <Database className="w-8 h-8 mx-auto text-slate-600 opacity-60" />
              <p className="text-xs">Nenhuma memória gravada ainda.</p>
              <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                Diga para Rick na conversa: <br />
                <span className="text-cyan-400/80 font-mono">"Rick, lembre-se que gosto de café amargo"</span>
              </p>
            </div>
          ) : (
            filteredMemories.map((item) => (
              <div
                key={item.id}
                className="p-3 bg-slate-950/80 border border-slate-800 hover:border-cyan-500/40 rounded-xl flex items-start justify-between gap-3 group transition"
              >
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-mono uppercase font-bold bg-cyan-950 text-cyan-400 border border-cyan-800/50">
                      {item.category || 'pessoal'}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">{item.createdAt}</span>
                    <span className="inline-flex items-center text-[10px] text-emerald-400 font-medium">
                      <ShieldCheck className="w-3 h-3 mr-0.5" /> Autorizada
                    </span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed font-sans">{item.content}</p>
                </div>
                <button
                  onClick={() => onDeleteMemory(item.id)}
                  className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-950/30 rounded-lg transition"
                  title="Excluir esta memória"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer controls */}
        {memories.length > 0 && (
          <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-mono text-[11px]">
              Total de fatos: {memories.length}
            </span>
            <button
              onClick={onRequestClearAll}
              className="text-red-400 hover:text-red-300 text-xs font-medium flex items-center gap-1 hover:underline"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Limpar todas (Requer Biometria)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
