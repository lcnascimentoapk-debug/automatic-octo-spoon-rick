import React, { useRef, useState, useEffect } from 'react';
import { Camera, SwitchCamera, X, ShieldAlert, Sparkles, Upload, Check } from 'lucide-react';

interface CameraVisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCaptureImage: (base64Data: string, mimeType: string) => void;
}

export const CameraVisionModal: React.FC<CameraVisionModalProps> = ({
  isOpen,
  onClose,
  onCaptureImage,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [permissionState, setPermissionState] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState<boolean>(false);

  // Stop video stream when modal closes
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
    }
  }, [isOpen]);

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
  };

  const requestCameraPermission = async () => {
    setErrorMsg(null);
    try {
      stopCamera();
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });
      setStream(mediaStream);
      setPermissionState('granted');
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.error('Camera permission denied or failed:', err);
      setPermissionState('denied');
      setErrorMsg(
        'Permissão de câmera negada ou câmera não detectada. Você pode selecionar uma imagem do dispositivo.'
      );
    }
  };

  const handleFlipCamera = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    if (permissionState === 'granted') {
      setTimeout(() => {
        requestCameraPermission();
      }, 50);
    }
  };

  const handleCapture = () => {
    if (!videoRef.current) return;
    setIsCapturing(true);

    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      const base64 = dataUrl.split(',')[1];
      stopCamera();
      onCaptureImage(base64, 'image/jpeg');
      onClose();
    }
    setIsCapturing(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        const mimeType = file.type || 'image/jpeg';
        const base64 = dataUrl.split(',')[1];
        stopCamera();
        onCaptureImage(base64, mimeType);
        onClose();
      }
    };
    reader.readAsDataURL(file);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-cyan-500/30 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950 border-b border-cyan-950/60">
          <div className="flex items-center space-x-2 text-cyan-400">
            <Camera className="w-5 h-5 text-cyan-400" />
            <h3 className="font-semibold text-sm text-slate-100 font-mono tracking-wide">
              RICK SCANNER — VISÃO MULTIMODAL
            </h3>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-4 flex-1 flex flex-col items-center justify-center min-h-[340px]">
          {/* Transparent Android Permission Prompt */}
          {permissionState === 'prompt' && (
            <div className="w-full max-w-sm bg-slate-950/90 border border-cyan-500/40 p-5 rounded-2xl text-center space-y-4 shadow-xl">
              <div className="w-14 h-14 bg-cyan-950/80 border border-cyan-400/40 rounded-full flex items-center justify-center mx-auto text-cyan-400">
                <Camera className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-slate-100 text-base">Permissão de Câmera Android</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Rick solicita permissão para capturar imagens e analisar objetos, textos ou o ambiente com sua visão multimodal.
                </p>
              </div>

              <div className="flex flex-col gap-2 pt-2">
                <button
                  onClick={requestCameraPermission}
                  className="w-full py-2.5 px-4 bg-gradient-to-r from-cyan-600 to-teal-500 hover:from-cyan-500 hover:to-teal-400 text-white font-semibold text-sm rounded-xl transition shadow-lg shadow-cyan-900/30 flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  Durante o uso do aplicativo
                </button>
                <label className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded-xl cursor-pointer transition flex items-center justify-center gap-2 border border-slate-700">
                  <Upload className="w-4 h-4 text-cyan-400" />
                  Carregar foto do dispositivo
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </div>
            </div>
          )}

          {/* Permission Denied state */}
          {permissionState === 'denied' && (
            <div className="w-full max-w-sm bg-slate-950/90 border border-red-500/40 p-5 rounded-2xl text-center space-y-4">
              <div className="w-12 h-12 bg-red-950/60 border border-red-500/50 rounded-full flex items-center justify-center mx-auto text-red-400">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-slate-100 text-sm">Acesso à Câmera Bloqueado</h4>
                <p className="text-xs text-slate-400">
                  {errorMsg || 'Acesso negado no navegador/Android. Você ainda pode analisar fotos enviando um arquivo.'}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={requestCameraPermission}
                  className="flex-1 py-2 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition"
                >
                  Tentar Novamente
                </button>
                <label className="flex-1 py-2 text-xs bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-center cursor-pointer transition flex items-center justify-center gap-1">
                  <Upload className="w-3.5 h-3.5" />
                  Galeria
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </div>
            </div>
          )}

          {/* Live Viewfinder */}
          {permissionState === 'granted' && (
            <div className="relative w-full h-[320px] rounded-xl overflow-hidden bg-black flex items-center justify-center border border-cyan-500/40">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />

              {/* Sci-fi HUD overlay */}
              <div className="absolute inset-0 pointer-events-none border-2 border-cyan-500/20 m-3 rounded-lg flex flex-col justify-between p-3">
                <div className="flex justify-between items-center text-[10px] font-mono text-cyan-400">
                  <span>TARGET_LOCK: ACTIVE</span>
                  <span>CAM: {facingMode.toUpperCase()}</span>
                </div>
                {/* Center crosshair */}
                <div className="self-center w-28 h-28 border border-dashed border-cyan-400/50 rounded-lg flex items-center justify-center">
                  <span className="w-2 h-2 rounded-full bg-cyan-400/80 animate-ping" />
                </div>
                <div className="flex justify-between items-center text-[10px] font-mono text-cyan-400/70">
                  <span>FOV: OPTICAL</span>
                  <span>AI_READY: GEMINI 3.8</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action bar */}
        {permissionState === 'granted' && (
          <div className="px-6 py-4 bg-slate-950 border-t border-cyan-950/60 flex items-center justify-between w-full">
            <button
              onClick={handleFlipCamera}
              className="p-3 bg-slate-800 text-slate-300 hover:text-white rounded-full border border-slate-700 hover:border-cyan-500 transition"
              title="Alternar Câmera Frontal / Traseira"
            >
              <SwitchCamera className="w-5 h-5" />
            </button>

            {/* Shutter Capture Button */}
            <button
              onClick={handleCapture}
              disabled={isCapturing}
              className="w-16 h-16 rounded-full p-1 bg-gradient-to-tr from-cyan-500 to-teal-400 shadow-lg shadow-cyan-500/40 hover:scale-105 active:scale-95 transition flex items-center justify-center"
              title="Tirar Foto para Rick Analisar"
            >
              <div className="w-full h-full rounded-full border-2 border-slate-950 bg-white/90 hover:bg-white flex items-center justify-center">
                <div className="w-11 h-11 rounded-full bg-cyan-600/20" />
              </div>
            </button>

            <label
              className="p-3 bg-slate-800 text-slate-300 hover:text-white rounded-full border border-slate-700 hover:border-cyan-500 cursor-pointer transition"
              title="Carregar Imagem da Galeria"
            >
              <Upload className="w-5 h-5" />
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />
            </label>
          </div>
        )}

        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
};
