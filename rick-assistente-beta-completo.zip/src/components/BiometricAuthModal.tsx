import React, { useState } from 'react';
import { Fingerprint, ShieldAlert, KeyRound, CheckCircle2, X } from 'lucide-react';

interface BiometricAuthModalProps {
  isOpen: boolean;
  reason: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const BiometricAuthModal: React.FC<BiometricAuthModalProps> = ({
  isOpen,
  reason,
  onConfirm,
  onCancel,
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSimulateFingerprint = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onConfirm();
      }, 700);
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-slate-900 border border-cyan-500/40 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center space-y-5">
        {/* Android Biometric Dialog icon */}
        <div className="w-16 h-16 rounded-full bg-cyan-950/80 border-2 border-cyan-400/50 flex items-center justify-center text-cyan-400 relative">
          {success ? (
            <CheckCircle2 className="w-9 h-9 text-emerald-400 animate-in zoom-in duration-200" />
          ) : (
            <Fingerprint
              className={`w-9 h-9 transition-transform ${
                isScanning ? 'animate-pulse text-cyan-300 scale-110' : ''
              }`}
            />
          )}
          {isScanning && (
            <span className="absolute inset-0 rounded-full border-2 border-cyan-400 animate-ping opacity-60" />
          )}
        </div>

        {/* Title and details */}
        <div className="space-y-1.5">
          <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 font-semibold">
            Segurança Android Biometrics
          </span>
          <h3 className="font-bold text-slate-100 text-lg">Confirmar Operação Sensível</h3>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-left space-y-1">
            <span className="text-[10px] uppercase font-mono text-slate-400 font-semibold block">
              Ação solicitada:
            </span>
            <p className="text-xs text-amber-300 font-medium leading-relaxed">{reason}</p>
          </div>
        </div>

        <p className="text-xs text-slate-400 max-w-xs">
          Rick exige validação biométrica antes de executar operações de alto impacto ou manipulação de dados sensíveis.
        </p>

        {/* Biometric Touch Trigger */}
        <div className="w-full space-y-2.5 pt-1">
          <button
            onClick={handleSimulateFingerprint}
            disabled={isScanning || success}
            className="w-full py-3 px-4 bg-gradient-to-r from-cyan-600 via-teal-500 to-cyan-500 hover:from-cyan-500 hover:to-teal-400 disabled:opacity-50 text-white font-semibold text-sm rounded-xl transition shadow-lg shadow-cyan-950 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Fingerprint className="w-5 h-5" />
            {isScanning ? 'Verificando biometria...' : success ? 'Autenticado!' : 'Tocar sensor de impressão digital'}
          </button>

          <button
            onClick={onCancel}
            disabled={isScanning}
            className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded-xl transition border border-slate-700"
          >
            Cancelar operação
          </button>
        </div>
      </div>
    </div>
  );
};
