import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Volume2,
  Sparkles,
  Check,
  RotateCcw,
  Sliders,
  Radio,
  AudioWaveform as Waveform,
  CheckCircle2,
  AlertCircle,
  X,
  Plus,
  Trash2,
  Play,
  Pause,
  Bot,
  UserCheck,
} from 'lucide-react';
import { VoiceProfile, VoiceSettings, PrebuiltGeminiVoice } from '../types/rick';
import { VoiceProfileManager, DEFAULT_VOICE_PROFILES } from '../services/VoiceProfileManager';
import { rickVoice } from '../services/RickVoiceEngine';

interface VoiceCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  voiceSettings: VoiceSettings;
  onUpdateSettings: (newSettings: VoiceSettings) => void;
}

export const VoiceCustomizerModal: React.FC<VoiceCustomizerModalProps> = ({
  isOpen,
  onClose,
  voiceSettings,
  onUpdateSettings,
}) => {
  const [activeTab, setActiveTab] = useState<'profiles' | 'clone' | 'tuning'>('profiles');
  const [activeProfileId, setActiveProfileId] = useState<string>(voiceSettings.activeProfileId);
  const [pitch, setPitch] = useState<number>(voiceSettings.pitch);
  const [rate, setRate] = useState<number>(voiceSettings.rate);
  const [useNeuralTTS, setUseNeuralTTS] = useState<boolean>(voiceSettings.useNeuralTTS);
  const [customProfiles, setCustomProfiles] = useState<VoiceProfile[]>(voiceSettings.customProfiles);

  // Voice recording & Cloning states
  const [isRecordingSample, setIsRecordingSample] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [recordedAudioBlob, setRecordedAudioBlob] = useState<Blob | null>(null);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [isAnalyzingVoice, setIsAnalyzingVoice] = useState<boolean>(false);
  const [cloneCustomName, setCloneCustomName] = useState<string>('Minha Voz / Voz Amostrada');
  const [cloneStatusMsg, setCloneStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [testSpeechStatus, setTestSpeechStatus] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  // Sync state if props change
  useEffect(() => {
    setActiveProfileId(voiceSettings.activeProfileId);
    setPitch(voiceSettings.pitch);
    setRate(voiceSettings.rate);
    setUseNeuralTTS(voiceSettings.useNeuralTTS);
    setCustomProfiles(voiceSettings.customProfiles);
  }, [voiceSettings]);

  // Clean up audio blob URL on unmount
  useEffect(() => {
    return () => {
      if (recordedAudioUrl) {
        URL.revokeObjectURL(recordedAudioUrl);
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [recordedAudioUrl]);

  if (!isOpen) return null;

  const allProfiles = [...DEFAULT_VOICE_PROFILES, ...customProfiles];
  const activeProfile = allProfiles.find((p) => p.id === activeProfileId) || DEFAULT_VOICE_PROFILES[0];

  // Apply changes globally
  const handleSaveAndApply = (profileId = activeProfileId, p = pitch, r = rate, neural = useNeuralTTS, list = customProfiles) => {
    const updated: VoiceSettings = {
      ...voiceSettings,
      activeProfileId: profileId,
      pitch: p,
      rate: r,
      useNeuralTTS: neural,
      customProfiles: list,
    };
    onUpdateSettings(updated);
    rickVoice.updateSettings(updated);
  };

  const handleSelectProfile = (profile: VoiceProfile) => {
    setActiveProfileId(profile.id);
    setPitch(profile.pitch);
    setRate(profile.rate);
    handleSaveAndApply(profile.id, profile.pitch, profile.rate, useNeuralTTS, customProfiles);
  };

  // Test speaking with the chosen voice
  const handleTestVoice = async (textToSpeak?: string) => {
    const text = textToSpeak || 'E aí! Rick falando aqui. Essa é a minha voz personalizada com síntese neural e cadência brasileira!';
    setTestSpeechStatus('Falando com a voz selecionada...');
    try {
      await rickVoice.speak(text, undefined, () => {
        setTestSpeechStatus(null);
      });
    } catch {
      setTestSpeechStatus(null);
    }
  };

  // Start recording user voice sample
  const handleStartRecording = async () => {
    try {
      setCloneStatusMsg(null);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setRecordedAudioBlob(audioBlob);
        const url = URL.createObjectURL(audioBlob);
        setRecordedAudioUrl(url);

        // Stop all audio tracks
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecordingSample(true);
      setRecordingSeconds(0);

      timerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => {
          if (prev >= 15) {
            handleStopRecording();
            return 15;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (err: any) {
      console.error('Erro ao acessar microfone para amostragem:', err);
      setCloneStatusMsg({
        type: 'error',
        text: 'Permissão de microfone negada ou indisponível para gravação de voz.',
      });
    }
  };

  // Stop recording
  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecordingSample) {
      mediaRecorderRef.current.stop();
      setIsRecordingSample(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  // Send audio sample to neural backend for acoustic profiling & cloning
  const handleAnalyzeAndCloneVoice = async () => {
    if (!recordedAudioBlob) return;
    setIsAnalyzingVoice(true);
    setCloneStatusMsg(null);

    try {
      // Convert blob to base64
      const reader = new FileReader();
      reader.readAsDataURL(recordedAudioBlob);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];

        const response = await fetch('/api/rick/voice-clone', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            audioBase64: base64Data,
            mimeType: recordedAudioBlob.type || 'audio/webm',
            name: cloneCustomName.trim() || 'Voz Clonada Personalizada',
          }),
        });

        if (!response.ok) {
          throw new Error('Falha na resposta do servidor');
        }

        const newProfile: VoiceProfile = await response.json();

        // Add to custom profiles
        const updatedList = [newProfile, ...customProfiles];
        setCustomProfiles(updatedList);
        setActiveProfileId(newProfile.id);
        setPitch(newProfile.pitch);
        setRate(newProfile.rate);

        handleSaveAndApply(newProfile.id, newProfile.pitch, newProfile.rate, useNeuralTTS, updatedList);

        setIsAnalyzingVoice(false);
        setCloneStatusMsg({
          type: 'success',
          text: `Voz "${newProfile.name}" calibrada e clonada com sucesso! O Rick falará continuamente com essa voz.`,
        });

        // Test speak immediately with cloned voice
        handleTestVoice(`Voz clonada ativada! A partir de agora, eu falarei continuamente com o seu padrão vocal e cadência.`);
      };
    } catch (err: any) {
      console.error('Erro na clonagem neural:', err);
      setIsAnalyzingVoice(false);
      setCloneStatusMsg({
        type: 'error',
        text: 'Não foi possível calibrar a amostra no momento. O Rick continuará usando a voz nativa configurada.',
      });
    }
  };

  const handleDeleteCustomVoice = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = customProfiles.filter((p) => p.id !== id);
    setCustomProfiles(updated);
    let newActive = activeProfileId;
    if (activeProfileId === id) {
      newActive = 'rick-classic';
      setActiveProfileId('rick-classic');
    }
    handleSaveAndApply(newActive, pitch, rate, useNeuralTTS, updated);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#080d1a] border border-cyan-500/50 rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh]">
        {/* Glow corners */}
        <div className="absolute -top-16 -right-16 w-44 h-44 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-44 h-44 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-cyan-950/80 pb-4 mb-4 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-gradient-to-tr from-cyan-950 to-emerald-950 border border-cyan-500/40 rounded-2xl text-cyan-400">
              <Volume2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-white font-mono tracking-wide">
                  CENTRAL DE VOZ DO RICK
                </h3>
                <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-500/40">
                  IA NEURAL
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Altere o timbre, clone a partir de uma amostra de áudio ou ajuste o tom
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-1.5 bg-slate-950/90 p-1 rounded-2xl border border-slate-800/80 mb-4 shrink-0">
          <button
            onClick={() => setActiveTab('profiles')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'profiles'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>Galeria de Vozes ({allProfiles.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('clone')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'clone'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>Clonar Voz por Amostra</span>
          </button>

          <button
            onClick={() => setActiveTab('tuning')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeTab === 'tuning'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>Ajuste Acústico</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {/* TAB 1: PROFILES GALLERY */}
          {activeTab === 'profiles' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>SELECIONE A VOZ ATIVA:</span>
                <span className="text-cyan-400 font-semibold">{activeProfile.name}</span>
              </div>

              <div className="space-y-2.5">
                {allProfiles.map((profile) => {
                  const isSelected = profile.id === activeProfileId;
                  return (
                    <div
                      key={profile.id}
                      onClick={() => handleSelectProfile(profile)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer relative flex flex-col gap-1.5 ${
                        isSelected
                          ? 'bg-cyan-950/70 border-cyan-400/80 shadow-lg shadow-cyan-950/50 ring-1 ring-cyan-400/50'
                          : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2.5">
                          <div
                            className={`p-2 rounded-xl border ${
                              profile.isCloned
                                ? 'bg-emerald-950 text-emerald-400 border-emerald-500/40'
                                : 'bg-slate-900 text-cyan-400 border-cyan-900/60'
                            }`}
                          >
                            {profile.isCloned ? (
                              <UserCheck className="w-4 h-4" />
                            ) : (
                              <Volume2 className="w-4 h-4" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-xs font-bold text-white font-mono">
                                {profile.name}
                              </h4>
                              {profile.isCloned && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                                  CLONADA
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">
                              Modelo Base: {profile.voiceName} • Tom: {profile.pitch.toFixed(2)}x • Vel: {profile.rate.toFixed(2)}x
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          {isSelected && (
                            <div className="p-1 rounded-full bg-cyan-500 text-black">
                              <Check className="w-3.5 h-3.5" />
                            </div>
                          )}
                          {profile.isCloned && (
                            <button
                              onClick={(e) => handleDeleteCustomVoice(profile.id, e)}
                              className="p-1.5 rounded-lg text-rose-400 hover:text-rose-200 hover:bg-rose-950/40 transition cursor-pointer"
                              title="Excluir voz clonada"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed pl-1">
                        {profile.description}
                      </p>

                      {isSelected && (
                        <div className="pt-2 mt-1 border-t border-cyan-900/40 flex items-center justify-between text-xs">
                          <span className="text-[11px] text-cyan-300/80 font-mono">
                            Voz contínua ativada
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleTestVoice();
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400 transition cursor-pointer"
                          >
                            <Play className="w-3 h-3 fill-current" />
                            <span>Testar Esta Voz</span>
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: VOICE CLONING FROM AUDIO SAMPLE */}
          {activeTab === 'clone' && (
            <div className="space-y-4">
              <div className="p-4 bg-gradient-to-br from-emerald-950/60 via-slate-950 to-cyan-950/50 border border-emerald-500/40 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold font-mono text-emerald-300 uppercase flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    Escuta e Clonagem de Amostra de Voz
                  </h4>
                  <span className="text-[10px] text-slate-400 font-mono">5 a 15 segundos</span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  Grave uma amostra da sua voz falando normalmente. O modelo neural do Rick analisa o timbre, cadência, ressonância e sotaque brasileiro para clonar o padrão vocal e falar continuamente dessa forma em todas as respostas!
                </p>

                {/* Suggested prompt to read */}
                <div className="p-3 bg-slate-950/90 border border-cyan-900/50 rounded-xl space-y-1">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-400">
                    Sugestão de frase para ler na gravação:
                  </span>
                  <p className="text-xs italic text-slate-200">
                    "Olá Rick, esta é a minha amostra de voz. Quero que você aprenda meu timbre e responda todas as minhas perguntas com essa voz de forma contínua."
                  </p>
                </div>

                {/* Name input */}
                <div className="space-y-1">
                  <label className="text-[11px] font-mono text-slate-300">Nome para esta Voz:</label>
                  <input
                    type="text"
                    value={cloneCustomName}
                    onChange={(e) => setCloneCustomName(e.target.value)}
                    placeholder="Ex: Minha Voz Lucas, Voz Enérgica, etc."
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-400"
                  />
                </div>

                {/* Recording Controls */}
                <div className="flex flex-col items-center justify-center p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-3">
                  {isRecordingSample ? (
                    <div className="flex flex-col items-center space-y-2">
                      <div className="relative flex items-center justify-center">
                        <div className="absolute -inset-3 rounded-full bg-rose-500/20 animate-ping" />
                        <button
                          onClick={handleStopRecording}
                          className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-950 transition cursor-pointer"
                        >
                          <Square className="w-6 h-6 fill-current" />
                        </button>
                      </div>
                      <span className="text-xs font-mono font-bold text-rose-400 animate-pulse">
                        Gravando amostra: {recordingSeconds}s / 15s (Clique para parar)
                      </span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center space-y-2">
                      <button
                        onClick={handleStartRecording}
                        className="w-16 h-16 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 hover:scale-105 text-white flex items-center justify-center shadow-lg shadow-emerald-950 transition cursor-pointer"
                      >
                        <Mic className="w-7 h-7" />
                      </button>
                      <span className="text-xs font-mono text-slate-300">
                        Clique para gravar a amostra de voz
                      </span>
                    </div>
                  )}

                  {/* Playback recorded sample */}
                  {recordedAudioUrl && !isRecordingSample && (
                    <div className="w-full pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-2.5">
                      <audio src={recordedAudioUrl} controls className="h-8 max-w-full text-xs" />
                      <button
                        onClick={handleAnalyzeAndCloneVoice}
                        disabled={isAnalyzingVoice}
                        className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md transition cursor-pointer disabled:opacity-50"
                      >
                        {isAnalyzingVoice ? (
                          <>
                            <span className="animate-spin w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full" />
                            Analisando Acústica...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4" />
                            Clonar e Ativar de Forma Contínua
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>

                {/* Status alerts */}
                {cloneStatusMsg && (
                  <div
                    className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                      cloneStatusMsg.type === 'success'
                        ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
                        : 'bg-rose-950/80 border-rose-500/50 text-rose-200'
                    }`}
                  >
                    {cloneStatusMsg.type === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span>{cloneStatusMsg.text}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: ACOUSTIC TUNING */}
          {activeTab === 'tuning' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-cyan-300 uppercase">
                    Configurações de Síntese
                  </span>
                  <button
                    onClick={() => {
                      setPitch(activeProfile.pitch);
                      setRate(activeProfile.rate);
                      handleSaveAndApply(activeProfileId, activeProfile.pitch, activeProfile.rate, useNeuralTTS);
                    }}
                    className="text-[11px] font-mono text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" /> Redefinir
                  </button>
                </div>

                {/* Neural TTS toggle */}
                <div className="flex items-center justify-between p-3 bg-slate-900 rounded-xl border border-slate-800">
                  <div>
                    <h5 className="text-xs font-bold text-white font-mono">
                      Síntese Neural Gemini 3.8
                    </h5>
                    <p className="text-[10px] text-slate-400">
                      Gera áudio natural em alta definição via nuvem (ou Web Speech offline)
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      const next = !useNeuralTTS;
                      setUseNeuralTTS(next);
                      handleSaveAndApply(activeProfileId, pitch, rate, next);
                    }}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      useNeuralTTS ? 'bg-cyan-600' : 'bg-slate-800'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        useNeuralTTS ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Pitch slider */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-medium">
                      Tom da Voz (Pitch / Grave ou Agudo):
                    </span>
                    <span className="text-cyan-400 font-mono font-semibold">
                      {pitch < 0.95 ? 'Grave / Encorpado' : pitch > 1.05 ? 'Agudo' : 'Equilibrado'} ({pitch.toFixed(2)})
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.75"
                    max="1.3"
                    step="0.02"
                    value={pitch}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setPitch(val);
                      handleSaveAndApply(activeProfileId, val, rate, useNeuralTTS);
                    }}
                    className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Mais Grave (0.75)</span>
                    <span>Padrão (1.00)</span>
                    <span>Mais Agudo (1.30)</span>
                  </div>
                </div>

                {/* Rate / Speed slider */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-medium">
                      Velocidade de Fala (Cadência):
                    </span>
                    <span className="text-cyan-400 font-mono font-semibold">
                      {rate > 1.15 ? 'Rápida / Dinâmica' : rate < 0.95 ? 'Pausada' : 'Normal'} ({rate.toFixed(2)}x)
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="1.35"
                    step="0.02"
                    value={rate}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setRate(val);
                      handleSaveAndApply(activeProfileId, pitch, val, useNeuralTTS);
                    }}
                    className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Pausada (0.8x)</span>
                    <span>Normal (1.0x)</span>
                    <span>Acelerada (1.35x)</span>
                  </div>
                </div>

                <button
                  onClick={() => handleTestVoice()}
                  className="w-full py-2.5 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Testar Afinação Atual
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono shrink-0">
          <div className="flex items-center gap-1.5">
            <Waveform className="w-3.5 h-3.5 text-cyan-400" />
            <span className="truncate max-w-[200px] text-slate-300">
              {activeProfile.name}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleTestVoice()}
              className="px-3 py-1.5 bg-cyan-950 border border-cyan-500/50 hover:bg-cyan-900 text-cyan-300 font-semibold rounded-lg transition text-xs cursor-pointer flex items-center gap-1"
            >
              <Play className="w-3 h-3 fill-current" />
              <span>Ouvir</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-lg transition text-xs cursor-pointer"
            >
              Confirmar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
