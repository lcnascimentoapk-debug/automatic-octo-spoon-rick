import React, { useState } from 'react';
import {
  Car,
  Navigation,
  Music,
  Compass,
  Mic,
  Volume2,
  Wind,
  PhoneCall,
  Play,
  Pause,
  SkipForward,
  Shield,
  Smartphone,
  MapPin,
} from 'lucide-react';
import { RickOrb } from './RickOrb';

interface CarMultimediaHUDProps {
  onTriggerVoice: () => void;
  voiceState: 'idle' | 'listening' | 'thinking' | 'speaking';
  onSwitchToPhone: () => void;
  lastRickResponse?: string;
}

export const CarMultimediaHUD: React.FC<CarMultimediaHUDProps> = ({
  onTriggerVoice,
  voiceState,
  onSwitchToPhone,
  lastRickResponse,
}) => {
  const [speed, setSpeed] = useState<number>(68);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [cabinTemp, setCabinTemp] = useState<number>(21.5);

  return (
    <div className="w-full flex-1 bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/40 p-4 md:p-6 flex flex-col justify-between select-none">
      {/* Top Automotive Bar */}
      <div className="flex items-center justify-between border-b border-cyan-900/50 pb-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-cyan-950/80 border border-cyan-500/40 rounded-xl text-cyan-400">
            <Car className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100 font-mono tracking-wider">
                RICK AUTO — HUD VEICULAR
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/40">
                MODO DIREÇÃO
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">Central Multimídia Conectada via CAN-Bus</p>
          </div>
        </div>

        {/* Back to Phone mode button */}
        <button
          onClick={onSwitchToPhone}
          className="flex items-center gap-2 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-semibold transition"
        >
          <Smartphone className="w-4 h-4" />
          Modo Smartphone
        </button>
      </div>

      {/* Main Automotive Dashboard Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 my-4 flex-1 items-center">
        {/* Speedometer & Car Telemetry Card */}
        <div className="bg-slate-950/80 border border-cyan-500/30 rounded-3xl p-5 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
          <div className="absolute top-3 left-4 text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-widest">
            Velocímetro Digital
          </div>
          <div className="my-3 flex flex-col items-center">
            <span className="text-6xl md:text-7xl font-extrabold font-mono text-transparent bg-clip-text bg-gradient-to-b from-white to-cyan-300">
              {speed}
            </span>
            <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest">
              KM/H
            </span>
          </div>

          {/* Interactive speed accelerator for simulation */}
          <div className="flex items-center gap-2 mt-2">
            <button
              onClick={() => setSpeed((s) => Math.max(0, s - 10))}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg font-mono"
            >
              -10
            </button>
            <span className="text-[11px] font-mono text-cyan-400 px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/30">
              MARCHA D
            </span>
            <button
              onClick={() => setSpeed((s) => Math.min(160, s + 10))}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg font-mono"
            >
              +10
            </button>
          </div>

          <div className="w-full mt-4 pt-3 border-t border-slate-800/80 flex justify-between text-xs font-mono text-slate-400">
            <span>Autonomia: 380 km</span>
            <span className="text-emerald-400">Pneus: 32 PSI</span>
          </div>
        </div>

        {/* Center: Rick Hands-Free Voice Core */}
        <div className="bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-cyan-500/40 rounded-3xl p-5 flex flex-col items-center justify-center shadow-2xl relative">
          <div className="absolute top-3 text-[10px] font-mono text-cyan-400 uppercase tracking-widest font-bold">
            Comando de Voz ao Volante
          </div>

          <div className="my-2">
            <RickOrb state={voiceState} onClick={onTriggerVoice} size="lg" />
          </div>

          <div className="w-full max-w-sm bg-slate-950/80 border border-slate-800 rounded-2xl p-3 text-center">
            <span className="text-[10px] font-mono text-slate-400 uppercase">
              Última mensagem do Rick:
            </span>
            <p className="text-xs text-slate-200 mt-0.5 line-clamp-2 italic">
              "{lastRickResponse || 'Olho na pista e mãos no volante. Se precisar de rota ou música, só chamar!'}"
            </p>
          </div>
        </div>

        {/* Navigation & Media Card */}
        <div className="flex flex-col gap-4">
          {/* GPS Navigation Card */}
          <div className="bg-slate-950/80 border border-cyan-500/30 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-cyan-950 border border-cyan-400/40 rounded-xl text-cyan-300">
                <Navigation className="w-6 h-6 rotate-45" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase">
                  Próxima Manobra • 450m
                </span>
                <h4 className="font-bold text-slate-100 text-sm">Av. das Américas, saída 12B</h4>
                <p className="text-xs text-slate-400">ETA: 18:42 • Tráfego fluindo bem</p>
              </div>
            </div>
            <MapPin className="w-5 h-5 text-emerald-400" />
          </div>

          {/* Media Player Card */}
          <div className="bg-slate-950/80 border border-cyan-500/30 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="w-10 h-10 rounded-lg bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <Music className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-100">Synthwave Drive 2088</h4>
                  <p className="text-[11px] text-slate-400">Rick Spotify Playlist</p>
                </div>
              </div>
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-10 h-10 rounded-full bg-cyan-600 hover:bg-cyan-500 text-white flex items-center justify-center transition"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
              </button>
            </div>

            {/* Audio wave bar simulation */}
            <div className="flex items-center gap-1 h-3 pt-1">
              {[40, 70, 90, 50, 30, 80, 100, 60, 45, 85, 95, 40, 60, 75].map((h, i) => (
                <div
                  key={i}
                  className="flex-1 bg-cyan-500/40 rounded-full transition-all duration-300"
                  style={{
                    height: isPlaying ? `${h}%` : '20%',
                    backgroundColor: isPlaying ? '#00f0ff' : '#475569',
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Automotive Control Strip */}
      <div className="bg-slate-950/90 border border-cyan-950 rounded-2xl p-3 flex items-center justify-around text-slate-300">
        <div className="flex items-center gap-2">
          <Wind className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-mono">Clima Cabine:</span>
          <button
            onClick={() => setCabinTemp((t) => Number((t - 0.5).toFixed(1)))}
            className="px-2 py-0.5 bg-slate-800 rounded text-xs"
          >
            -
          </button>
          <span className="text-xs font-mono font-bold text-cyan-300">{cabinTemp}°C</span>
          <button
            onClick={() => setCabinTemp((t) => Number((t + 0.5).toFixed(1)))}
            className="px-2 py-0.5 bg-slate-800 rounded text-xs"
          >
            +
          </button>
        </div>

        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-mono text-emerald-400">Piloto Assistido: Ativo</span>
        </div>

        <div className="flex items-center gap-2">
          <PhoneCall className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-mono">Chamadas sem mãos: Pronto</span>
        </div>
      </div>
    </div>
  );
};
