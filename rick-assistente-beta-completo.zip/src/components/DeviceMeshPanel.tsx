import React, { useState } from 'react';
import {
  Share2,
  Tablet,
  Watch,
  Car,
  Tv,
  Smartphone,
  RefreshCw,
  Send,
  CheckCircle,
  Wifi,
  Radio,
  Lock,
} from 'lucide-react';
import { ConnectedDevice } from '../types/rick';

interface DeviceMeshPanelProps {
  devices: ConnectedDevice[];
  onSendMessageToDevice: (deviceId: string, text: string) => void;
}

export const DeviceMeshPanel: React.FC<DeviceMeshPanelProps> = ({
  devices,
  onSendMessageToDevice,
}) => {
  const [selectedDevice, setSelectedDevice] = useState<string>(devices[0]?.id || '');
  const [taskText, setTaskText] = useState<string>('');
  const [sentSuccess, setSentSuccess] = useState<string | null>(null);

  const getDeviceIcon = (type: ConnectedDevice['type']) => {
    switch (type) {
      case 'tablet':
        return <Tablet className="w-5 h-5 text-cyan-400" />;
      case 'watch':
        return <Watch className="w-5 h-5 text-emerald-400" />;
      case 'car':
        return <Car className="w-5 h-5 text-amber-400" />;
      case 'tv':
        return <Tv className="w-5 h-5 text-violet-400" />;
      default:
        return <Smartphone className="w-5 h-5 text-cyan-400" />;
    }
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskText.trim() || !selectedDevice) return;
    onSendMessageToDevice(selectedDevice, taskText.trim());
    const dev = devices.find((d) => d.id === selectedDevice);
    setSentSuccess(`Comando transmitido para ${dev?.name || 'dispositivo'} via Mesh`);
    setTaskText('');
    setTimeout(() => setSentSuccess(null), 3500);
  };

  return (
    <div className="flex-1 bg-slate-950 p-4 md:p-6 overflow-y-auto space-y-6">
      {/* Top Banner */}
      <div className="flex items-center justify-between border-b border-cyan-900/40 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-cyan-950 border border-cyan-500/40 rounded-xl text-cyan-400">
            <Radio className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100 font-mono tracking-wide">
              RICK ANDROID MESH — INTER-DISPOSITIVOS
            </h2>
            <p className="text-xs text-slate-400">
              Protocolo P2P de comunicação distribuída e sincronização de tarefas
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 rounded-full text-xs font-mono">
          <Lock className="w-3.5 h-3.5" />
          E2EE Criptografado
        </div>
      </div>

      {/* Discovered Devices Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
            Dispositivos Android Pareados ({devices.length})
          </h3>
          <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
            <Wifi className="w-3 h-3 text-cyan-400" /> Rede Mesh Ativa
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {devices.map((device) => {
            const isSelected = selectedDevice === device.id;
            return (
              <div
                key={device.id}
                onClick={() => setSelectedDevice(device.id)}
                className={`p-4 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? 'bg-cyan-950/50 border-cyan-400 shadow-lg shadow-cyan-950/50'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    {getDeviceIcon(device.type)}
                  </div>
                  <div>
                    <h4 className="font-semibold text-xs text-slate-100">{device.name}</h4>
                    <p className="text-[10px] text-slate-400 font-mono">IP: {device.ip}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span
                        className={`inline-flex items-center text-[9px] font-mono font-bold px-1.5 py-0.2 rounded ${
                          device.isConnected
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {device.isConnected ? 'ONLINE' : 'STANDBY'}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Bateria: {device.battery}%
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-500 font-mono block">
                    Última sincronização
                  </span>
                  <span className="text-[11px] text-cyan-300 font-mono font-medium">
                    {device.lastSync}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Broadcast / Direct Task Sender */}
      <div className="bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-4 md:p-5 space-y-3">
        <h3 className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wide flex items-center gap-2">
          <Share2 className="w-4 h-4 text-cyan-400" />
          Transmitir Tarefa / Notificação entre Dispositivos
        </h3>

        <form onSubmit={handleSend} className="space-y-3">
          <div>
            <label className="text-[11px] text-slate-400 font-mono block mb-1">
              Dispositivo de Destino:
            </label>
            <select
              value={selectedDevice}
              onChange={(e) => setSelectedDevice(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-3 py-2.5 focus:border-cyan-400 focus:outline-none"
            >
              {devices.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.type.toUpperCase()}) - {d.isConnected ? 'Conectado' : 'Offline'}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] text-slate-400 font-mono block mb-1">
              Mensagem ou Ação de Comando:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Ex: 'Continuar reprodução de música', 'Enviar rota do GPS', 'Sincronizar clipboard'..."
                value={taskText}
                onChange={(e) => setTaskText(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-700 text-slate-100 text-xs rounded-xl px-3 py-2.5 focus:border-cyan-400 focus:outline-none placeholder:text-slate-500"
              />
              <button
                type="submit"
                disabled={!taskText.trim()}
                className="px-4 py-2.5 bg-gradient-to-r from-cyan-600 to-teal-500 hover:from-cyan-500 hover:to-teal-400 disabled:opacity-50 text-white font-semibold text-xs rounded-xl transition flex items-center gap-1.5 shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                Transmitir
              </button>
            </div>
          </div>
        </form>

        {sentSuccess && (
          <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in duration-200">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{sentSuccess}</span>
          </div>
        )}
      </div>
    </div>
  );
};
