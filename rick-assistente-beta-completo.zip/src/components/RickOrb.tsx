import React from 'react';
import { Mic, MicOff, Volume2, Sparkles, Loader2 } from 'lucide-react';

interface RickOrbProps {
  state: 'idle' | 'listening' | 'thinking' | 'speaking';
  onClick: () => void;
  size?: 'sm' | 'md' | 'lg';
}

export const RickOrb: React.FC<RickOrbProps> = ({ state, onClick, size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-24 h-24',
    md: 'w-36 h-36',
    lg: 'w-48 h-48',
  }[size];

  const getStatusLabel = () => {
    switch (state) {
      case 'listening':
        return 'Ouvindo você...';
      case 'thinking':
        return 'Rick processando...';
      case 'speaking':
        return 'Rick falando...';
      default:
        return 'Toque para falar com Rick';
    }
  };

  return (
    <div className="flex flex-col items-center justify-center select-none py-2">
      <div className="relative flex items-center justify-center">
        {/* Outer glowing ripple effects */}
        {state === 'listening' && (
          <>
            <div className="absolute -inset-4 rounded-full bg-amber-500/20 animate-ping opacity-60 pointer-events-none" />
            <div className="absolute -inset-8 rounded-full bg-amber-400/10 animate-pulse pointer-events-none" />
          </>
        )}
        {state === 'thinking' && (
          <div className="absolute -inset-6 rounded-full border-2 border-dashed border-cyan-400/40 animate-spin pointer-events-none" />
        )}
        {state === 'speaking' && (
          <>
            <div className="absolute -inset-4 rounded-full bg-cyan-500/25 animate-pulse pointer-events-none" />
            <div className="absolute -inset-8 rounded-full bg-emerald-500/15 animate-ping opacity-40 pointer-events-none" />
          </>
        )}

        {/* Central interactive orb button */}
        <button
          onClick={onClick}
          aria-label={getStatusLabel()}
          className={`relative ${sizeClasses} rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 shadow-2xl focus:outline-none ${
            state === 'listening'
              ? 'bg-gradient-to-tr from-amber-600 via-orange-500 to-yellow-400 shadow-amber-500/50 scale-105 ring-4 ring-amber-400/60'
              : state === 'thinking'
              ? 'bg-gradient-to-tr from-cyan-700 via-blue-600 to-indigo-500 shadow-cyan-500/50 scale-100 ring-4 ring-cyan-400/50'
              : state === 'speaking'
              ? 'bg-gradient-to-tr from-cyan-500 via-teal-500 to-emerald-400 shadow-cyan-400/60 scale-105 ring-4 ring-cyan-300/80'
              : 'bg-gradient-to-tr from-slate-900 via-cyan-950 to-slate-800 border border-cyan-500/30 shadow-cyan-950/40 hover:scale-105 hover:border-cyan-400/60'
          }`}
        >
          {/* Inner core texture */}
          <div className="absolute inset-1.5 rounded-full bg-slate-950/60 backdrop-blur-sm flex items-center justify-center overflow-hidden">
            {/* Ambient cyber grid scan lines */}
            <div className="absolute inset-0 bg-[radial-gradient(#00f0ff_1px,transparent_1px)] [background-size:12px_12px] opacity-25" />

            {/* Icon status display */}
            <div className="relative z-10 flex flex-col items-center justify-center text-white transition-transform">
              {state === 'listening' && (
                <div className="flex flex-col items-center">
                  <Mic className="w-9 h-9 text-amber-300 animate-bounce" />
                  <span className="text-[10px] uppercase font-bold tracking-widest text-amber-200 mt-1">Ouvindo</span>
                </div>
              )}
              {state === 'thinking' && (
                <div className="flex flex-col items-center">
                  <Loader2 className="w-9 h-9 text-cyan-300 animate-spin" />
                  <span className="text-[10px] uppercase font-bold tracking-widest text-cyan-200 mt-1">Pensando</span>
                </div>
              )}
              {state === 'speaking' && (
                <div className="flex flex-col items-center space-y-1">
                  <div className="flex items-center space-x-1 h-8">
                    <span className="w-1.5 h-4 bg-cyan-300 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <span className="w-1.5 h-7 bg-emerald-300 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <span className="w-1.5 h-5 bg-teal-300 rounded-full animate-bounce" />
                    <span className="w-1.5 h-6 bg-cyan-300 rounded-full animate-bounce [animation-delay:-0.25s]" />
                  </div>
                  <span className="text-[10px] uppercase font-bold tracking-widest text-cyan-200">Falando</span>
                </div>
              )}
              {state === 'idle' && (
                <div className="flex flex-col items-center text-cyan-400 hover:text-cyan-300">
                  <Mic className="w-9 h-9 text-cyan-400 group-hover:scale-110 transition-transform" />
                  <span className="text-[9px] uppercase tracking-wider text-cyan-400/80 font-mono mt-1">Rick Beta</span>
                </div>
              )}
            </div>
          </div>
        </button>
      </div>

      {/* Subtitle helper */}
      <p className="mt-2.5 text-xs font-mono font-medium text-slate-400 flex items-center gap-1.5 tracking-wide">
        <span
          className={`w-2 h-2 rounded-full ${
            state === 'listening'
              ? 'bg-amber-400 animate-ping'
              : state === 'speaking'
              ? 'bg-cyan-400 animate-pulse'
              : state === 'thinking'
              ? 'bg-indigo-400'
              : 'bg-emerald-500'
          }`}
        />
        {getStatusLabel()}
      </p>
    </div>
  );
};
