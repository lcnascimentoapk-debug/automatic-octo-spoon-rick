import React from 'react';
import {
  Flashlight,
  Volume2,
  Battery,
  Bell,
  Camera,
  Database,
  Car,
  Calculator,
  MapPin,
  Users,
  Settings,
  X,
  Smartphone,
  Music,
  Wifi,
  WifiOff,
  HardDrive,
  Trash2,
  Download,
} from 'lucide-react';
import { SystemState } from '../types/rick';

interface AndroidToolsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  systemState: SystemState;
  onToggleTorch: () => void;
  onChangeVolume: (vol: number) => void;
  onTriggerNotification: () => void;
  onOpenCamera: () => void;
  onOpenMemoryVault: () => void;
  onSwitchMode: (mode: SystemState['deviceMode']) => void;
  onLaunchApp: (appName: string) => void;
  onToggleOffline: () => void;
  onClearLocalCache: () => void;
  onOpenDownloadModal?: () => void;
  onOpenInstallModal?: () => void;
  onOpenVoiceModal?: () => void;
}

export const AndroidToolsDrawer: React.FC<AndroidToolsDrawerProps> = ({
  isOpen,
  onClose,
  systemState,
  onToggleTorch,
  onChangeVolume,
  onTriggerNotification,
  onOpenCamera,
  onOpenMemoryVault,
  onSwitchMode,
  onLaunchApp,
  onToggleOffline,
  onClearLocalCache,
  onOpenDownloadModal,
  onOpenInstallModal,
  onOpenVoiceModal,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-slate-900 border-l border-cyan-500/30 h-full p-5 overflow-y-auto flex flex-col justify-between shadow-2xl">
        <div className="space-y-5">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-cyan-950 pb-3">
            <div className="flex items-center space-x-2 text-cyan-400">
              <Smartphone className="w-5 h-5 text-cyan-400" />
              <h3 className="font-bold text-sm text-slate-100 font-mono tracking-wide">
                CENTRAL DE FERRAMENTAS ANDROID
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Offline Mode Master Switch */}
          <div className="bg-slate-950/80 border border-amber-500/40 rounded-2xl p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div
                  className={`p-2 rounded-xl ${
                    systemState.isOffline
                      ? 'bg-amber-950 text-amber-400 border border-amber-500/50'
                      : 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                  }`}
                >
                  {systemState.isOffline ? (
                    <WifiOff className="w-5 h-5" />
                  ) : (
                    <Wifi className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-100 font-mono">
                    MODO OFFLINE COMPLETO
                  </h4>
                  <p className="text-[10px] text-slate-400 font-mono">
                    {systemState.isOffline
                      ? 'Motor local ativo (Zero internet)'
                      : 'Modo online / Rede disponível'}
                  </p>
                </div>
              </div>

              {/* Toggle switch button */}
              <button
                onClick={onToggleOffline}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                  systemState.isOffline ? 'bg-amber-600' : 'bg-slate-800'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    systemState.isOffline ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              No modo offline, o Rick executa seu cérebro local diretamente na sua máquina via PWA
              Service Worker com armazenamento em IndexedDB/LocalStorage, voz nativa e controles de
              hardware sem conexão externa.
            </p>
          </div>

          {/* Quick System Toggles */}
          <div className="space-y-2">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
              Ações Rápidas de Hardware
            </span>
            <div className="grid grid-cols-2 gap-2.5">
              {/* Torch button */}
              <button
                onClick={onToggleTorch}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center text-center transition ${
                  systemState.isTorchOn
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <Flashlight
                  className={`w-5 h-5 mb-1 ${
                    systemState.isTorchOn ? 'text-amber-400 animate-pulse' : ''
                  }`}
                />
                <span className="text-xs font-semibold">Lanterna</span>
                <span className="text-[10px] text-slate-400">
                  {systemState.isTorchOn ? 'Ligada' : 'Desligada'}
                </span>
              </button>

              {/* Camera Scanner button */}
              <button
                onClick={() => {
                  onClose();
                  onOpenCamera();
                }}
                className="p-3 rounded-xl border bg-slate-950/80 border-slate-800 hover:border-cyan-400 text-slate-300 flex flex-col items-center justify-center text-center transition"
              >
                <Camera className="w-5 h-5 mb-1 text-cyan-400" />
                <span className="text-xs font-semibold">Câmera Rick</span>
                <span className="text-[10px] text-slate-400">Análise Visual</span>
              </button>

              {/* Memory Vault button */}
              <button
                onClick={() => {
                  onClose();
                  onOpenMemoryVault();
                }}
                className="p-3 rounded-xl border bg-slate-950/80 border-slate-800 hover:border-cyan-400 text-slate-300 flex flex-col items-center justify-center text-center transition"
              >
                <Database className="w-5 h-5 mb-1 text-emerald-400" />
                <span className="text-xs font-semibold">Cofre Memórias</span>
                <span className="text-[10px] text-slate-400">Gerenciar Fatos</span>
              </button>

              {/* Android Notification button */}
              <button
                onClick={onTriggerNotification}
                className="p-3 rounded-xl border bg-slate-950/80 border-slate-800 hover:border-cyan-400 text-slate-300 flex flex-col items-center justify-center text-center transition"
              >
                <Bell className="w-5 h-5 mb-1 text-indigo-400" />
                <span className="text-xs font-semibold">Notificação</span>
                <span className="text-[10px] text-slate-400">Testar Push</span>
              </button>

              {/* Voice Customizer button */}
              {onOpenVoiceModal && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenVoiceModal();
                  }}
                  className="p-3 rounded-xl border bg-slate-950/80 border-cyan-500/40 hover:border-cyan-400 text-cyan-300 flex flex-col items-center justify-center text-center transition"
                >
                  <Volume2 className="w-5 h-5 mb-1 text-cyan-400" />
                  <span className="text-xs font-semibold">Voz do Rick</span>
                  <span className="text-[10px] text-slate-400">Clonar / Sintetizar</span>
                </button>
              )}
            </div>
          </div>

          {/* Volume Slider */}
          <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-cyan-400" /> Volume de Mídia
              </span>
              <span className="text-cyan-400 font-mono font-semibold">{systemState.volume}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={systemState.volume}
              onChange={(e) => onChangeVolume(Number(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />
          </div>

          {/* Android App Launcher Simulator */}
          <div className="space-y-2">
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
              Lançador de Aplicativos Android
            </span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { name: 'Calculadora', icon: Calculator, color: 'text-amber-400' },
                { name: 'Mapas', icon: MapPin, color: 'text-emerald-400' },
                { name: 'Contatos', icon: Users, color: 'text-cyan-400' },
                { name: 'Música', icon: Music, color: 'text-pink-400' },
                { name: 'Configurações', icon: Settings, color: 'text-slate-300' },
                { name: 'Rick Auto', icon: Car, color: 'text-teal-400' },
              ].map((app) => (
                <button
                  key={app.name}
                  onClick={() => {
                    if (app.name === 'Rick Auto') {
                      onSwitchMode('car');
                      onClose();
                    } else {
                      onLaunchApp(app.name);
                    }
                  }}
                  className="p-2.5 bg-slate-950/70 border border-slate-800 hover:border-cyan-500/50 rounded-xl flex flex-col items-center justify-center gap-1 transition text-center"
                >
                  <app.icon className={`w-5 h-5 ${app.color}`} />
                  <span className="text-[10px] text-slate-300 truncate w-full">{app.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Offline Cache Maintenance */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-mono text-[11px] flex items-center gap-1">
              <HardDrive className="w-3.5 h-3.5 text-cyan-400" /> Cache local PWA
            </span>
            <button
              onClick={onClearLocalCache}
              className="text-[10px] font-mono text-rose-400 hover:text-rose-300 flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" /> Limpar Histórico Local
            </button>
          </div>
        </div>

        {/* Footer switch to car or mesh and Download */}
        <div className="pt-4 border-t border-slate-800 space-y-2">
          {onOpenInstallModal && (
            <button
              onClick={() => {
                onClose();
                onOpenInstallModal();
              }}
              className="w-full py-2.5 px-3 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition cursor-pointer"
            >
              <Smartphone className="w-4 h-4" />
              Instalar Aplicativo no Android
            </button>
          )}

          {onOpenDownloadModal && (
            <button
              onClick={() => {
                onClose();
                onOpenDownloadModal();
              }}
              className="w-full py-2.5 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              Central de Download (ZIP / Código Fonte)
            </button>
          )}

          <button
            onClick={() => {
              onSwitchMode('car');
              onClose();
            }}
            className="w-full py-2.5 px-3 bg-gradient-to-r from-cyan-600 to-teal-500 hover:from-cyan-500 hover:to-teal-400 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-cyan-950 transition cursor-pointer"
          >
            <Car className="w-4 h-4" />
            Abrir Central Veicular (Rick Auto)
          </button>
        </div>
      </div>
    </div>
  );
};
