import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  X,
  CheckCircle2,
  Download,
  Share2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  HardDriveDownload,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  deferredPrompt?: any;
}

export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = ({
  isOpen,
  onClose,
  deferredPrompt,
}) => {
  const [installPrompt, setInstallPrompt] = useState<any>(deferredPrompt || null);
  const [isInstalling, setIsInstalling] = useState<boolean>(false);
  const [installedSuccessfully, setInstalledSuccessfully] = useState<boolean>(false);
  const [activeStep, setActiveStep] = useState<number>(1);

  // Capture install prompt event if triggered during view
  useEffect(() => {
    if (deferredPrompt) {
      setInstallPrompt(deferredPrompt);
    }

    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    const handleAppInstalled = () => {
      setInstalledSuccessfully(true);
      setInstallPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, [deferredPrompt]);

  if (!isOpen) return null;

  // Handle direct 1-click install prompt if browser allows
  const handleTriggerNativeInstall = async () => {
    if (installPrompt) {
      setIsInstalling(true);
      try {
        await installPrompt.prompt();
        const choice = await installPrompt.userChoice;
        if (choice && choice.outcome === 'accepted') {
          setInstalledSuccessfully(true);
        }
      } catch (err) {
        console.warn('Erro ao acionar prompt nativo:', err);
      } finally {
        setIsInstalling(false);
      }
    } else {
      setActiveStep(2);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0b101f] border border-cyan-500/50 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh]">
        {/* Glow corners */}
        <div className="absolute -top-14 -right-14 w-40 h-40 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-14 -left-14 w-40 h-40 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-cyan-950 pb-4 mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-gradient-to-tr from-emerald-950 to-cyan-950 border border-emerald-500/40 rounded-2xl text-emerald-400">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-white font-mono tracking-wide">
                  INSTALAR RICK NO ANDROID
                </h3>
                <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                  DIRETO NO CELULAR
                </span>
              </div>
              <p className="text-xs text-slate-400">
                PWA Nativo com ícone na tela inicial e modo 100% offline
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {/* Success Banner if already installed */}
          {installedSuccessfully && (
            <div className="p-4 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl flex items-center gap-3 text-emerald-200 text-xs">
              <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
              <div>
                <p className="font-bold">Rick instalado com sucesso!</p>
                <p className="text-emerald-300/80 text-[11px]">
                  O ícone do Rick agora está na sua tela inicial do Android e gaveta de apps.
                </p>
              </div>
            </div>
          )}

          {/* Quick Action Button for Direct Install */}
          <div className="p-4 bg-gradient-to-br from-emerald-950/70 via-slate-950 to-cyan-950/60 border border-emerald-500/40 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-emerald-300 flex items-center gap-1.5 uppercase">
                <Zap className="w-4 h-4 text-emerald-400" /> Instalação com 1 Toque
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Chrome / Edge / Brave</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              O Rick é um aplicativo nativo Progressive Web App (PWA). Ele é instalado diretamente no seu Android sem precisar de downloads externos perigosos ou contas intermediárias.
            </p>

            <button
              onClick={handleTriggerNativeInstall}
              disabled={isInstalling}
              className="w-full py-3 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition cursor-pointer"
            >
              {isInstalling ? (
                <>
                  <span className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                  Abrindo diálogo do Android...
                </>
              ) : (
                <>
                  <HardDriveDownload className="w-5 h-5" />
                  Instalar Rick no Android Agora
                </>
              )}
            </button>
          </div>

          {/* Visual Step by Step Guide for Android (Chrome / Samsung Internet / Brave) */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold font-mono text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              Passo a Passo Manual no Celular
            </h4>

            <div className="space-y-2.5">
              {/* Step 1 */}
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-400 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                  1
                </span>
                <div className="text-xs space-y-0.5">
                  <p className="font-semibold text-slate-200">Abra o menu do navegador</p>
                  <p className="text-slate-400 leading-relaxed">
                    No Google Chrome ou no navegador do seu Android, toque no ícone de <strong>três pontinhos (⋮)</strong> no canto superior direito.
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-3 bg-slate-950/80 border border-cyan-900/40 rounded-xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-cyan-950 border border-cyan-500/40 text-cyan-400 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                  2
                </span>
                <div className="text-xs space-y-0.5">
                  <p className="font-semibold text-slate-200">
                    Toque em "Instalar aplicativo" ou "Adicionar à tela inicial"
                  </p>
                  <p className="text-slate-400 leading-relaxed">
                    Selecione a opção com o ícone de download/celular na lista de opções.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-500/40 text-emerald-400 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                  3
                </span>
                <div className="text-xs space-y-0.5">
                  <p className="font-semibold text-slate-200">Confirme a Instalação</p>
                  <p className="text-slate-400 leading-relaxed">
                    Clique em <strong>"Instalar"</strong>. O Rick será adicionado à sua tela inicial como um app nativo independente, sem barra de navegação e com inicialização instantânea!
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Android PWA Native Benefits */}
          <div className="p-3.5 bg-slate-950/60 border border-slate-800/80 rounded-2xl space-y-2">
            <span className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider">
              Recursos Natos no seu Android:
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Modo 100% Offline</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Microfone e Voz Nativa</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Scanner Óptico / Câmera</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Controle de Lanterna e Volume</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Central Veicular Rick Auto</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Rede Mesh de Dispositivos</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span className="flex items-center gap-1 text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            Certificado Seguro & Leve
          </span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition text-xs font-sans cursor-pointer"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
