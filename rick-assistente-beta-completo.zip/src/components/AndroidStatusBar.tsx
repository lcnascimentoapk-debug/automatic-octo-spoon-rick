import React, { useState, useEffect } from 'react';
import {
  Wifi,
  WifiOff,
  Signal,
  Battery,
  BatteryCharging,
  ShieldCheck,
  Zap,
  HardDriveDownload,
} from 'lucide-react';

interface AndroidStatusBarProps {
  battery: number;
  isCharging: boolean;
  isOffline: boolean;
  onOpenTools?: () => void;
  onToggleOffline?: () => void;
}

export const AndroidStatusBar: React.FC<AndroidStatusBarProps> = ({
  battery,
  isCharging,
  isOffline,
  onOpenTools,
  onToggleOffline,
}) => {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString('pt-BR', {
          hour: '2-digit',
          minute: '2-digit',
        })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="w-full bg-slate-950/85 backdrop-blur-md border-b border-cyan-900/30 text-slate-300 px-3 sm:px-4 py-2 flex items-center justify-between text-xs select-none sticky top-0 z-40">
      {/* Time & Android brand indicator */}
      <div className="flex items-center space-x-2 font-mono font-semibold text-slate-200">
        <span className="text-sm tracking-tight">{time || '12:00'}</span>
        <span className="hidden xs:inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-400 border border-cyan-500/30">
          ANDROID 15
        </span>
        {isOffline ? (
          <button
            onClick={onToggleOffline}
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950/90 text-amber-300 border border-amber-500/50 animate-pulse hover:bg-amber-900 transition cursor-pointer"
            title="Clique para alternar conexão"
          >
            <WifiOff className="w-3 h-3 text-amber-400" />
            <span>MODO OFFLINE</span>
          </button>
        ) : (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/40">
            ONLINE
          </span>
        )}
      </div>

      {/* Center notch / Rick status pill */}
      <div
        onClick={onOpenTools}
        className="flex items-center gap-1.5 bg-slate-900/90 border border-cyan-500/40 rounded-full px-2.5 py-0.5 text-[11px] font-medium text-cyan-300 shadow-sm cursor-pointer hover:border-cyan-400 transition-colors"
        title="Painel de Ferramentas Android"
      >
        <span className="relative flex h-2 w-2">
          <span
            className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
              isOffline ? 'bg-amber-400' : 'bg-cyan-400'
            }`}
          />
          <span
            className={`relative inline-flex rounded-full h-2 w-2 ${
              isOffline ? 'bg-amber-500' : 'bg-cyan-500'
            }`}
          />
        </span>
        <span className="font-semibold tracking-wider">
          {isOffline ? 'RICK LOCAL' : 'RICK BETA'}
        </span>
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
      </div>

      {/* Network & Battery Status */}
      <div className="flex items-center space-x-2 font-mono text-slate-400">
        <span className="text-[10px] font-bold text-slate-400 hidden sm:inline">
          {isOffline ? 'AIRPLANE' : '5G'}
        </span>
        <Signal className="w-3.5 h-3.5 text-slate-300" />
        {isOffline ? (
          <span title="Sem conexão com a internet">
            <WifiOff className="w-3.5 h-3.5 text-amber-400" />
          </span>
        ) : (
          <span title="Wi-Fi 6E Conectado">
            <Wifi className="w-3.5 h-3.5 text-cyan-400" />
          </span>
        )}
        <div className="flex items-center space-x-1 pl-1 text-slate-200 font-semibold">
          <span>{battery}%</span>
          {isCharging ? (
            <BatteryCharging className="w-4 h-4 text-emerald-400" />
          ) : (
            <Battery className="w-4 h-4 text-slate-300" />
          )}
        </div>
      </div>
    </header>
  );
};
