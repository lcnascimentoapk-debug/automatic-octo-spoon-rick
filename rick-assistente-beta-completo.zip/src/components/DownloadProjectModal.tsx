import React, { useState } from 'react';
import {
  Download,
  X,
  FileArchive,
  FolderArchive,
  Smartphone,
  CheckCircle2,
  HardDriveDownload,
  ExternalLink,
  ShieldCheck,
  FileCode,
  Sparkles,
} from 'lucide-react';
import JSZip from 'jszip';
import { KOTLIN_CODEBASE } from './KotlinCodeViewer';

interface DownloadProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadProjectModal: React.FC<DownloadProjectModalProps> = ({ isOpen, onClose }) => {
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isDownloadingFull, setIsDownloadingFull] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [fullZipSuccess, setFullZipSuccess] = useState<boolean>(false);
  const [deferredInstallPrompt, setDeferredInstallPrompt] = useState<any>(null);

  React.useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredInstallPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  if (!isOpen) return null;

  // Download entire current project (React, Express server, PWA, Kotlin components, config files)
  const handleDownloadFullAppZip = async () => {
    setIsDownloadingFull(true);
    setFullZipSuccess(false);

    try {
      const response = await fetch('/api/rick/download-full-project-zip');
      if (!response.ok) {
        throw new Error('Falha no servidor ao gerar arquivo ZIP.');
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'rick-assistente-beta-completo.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setIsDownloadingFull(false);
      setFullZipSuccess(true);
      setTimeout(() => setFullZipSuccess(false), 5000);
    } catch (err) {
      console.error('Erro ao baixar ZIP completo:', err);
      setIsDownloadingFull(false);
      // Fallback: direct browser trigger
      window.location.href = '/api/rick/download-full-project-zip';
    }
  };

  // Generate and download standard Android Studio ZIP project
  const handleDownloadAndroidZip = async () => {
    setIsGenerating(true);
    setDownloadSuccess(false);

    try {
      const zip = new JSZip();

      // README
      zip.file(
        'README.md',
        `# Rick — Assistente Inteligente Beta (Android Native)

Este projeto contém a arquitetura nativa completa em **Kotlin** e **Jetpack Compose** para o Rick Assistente.

## Como Executar no Android Studio:
1. Abra o Android Studio (Ladybug / Koala ou superior).
2. Selecione **File > Open** e escolha a pasta descompactada.
3. Aguarde o Gradle sincronizar com o SDK 35 (Android 15).
4. No arquivo \`local.properties\`, adicione sua chave Gemini:
   \`\`\`properties
   GEMINI_API_KEY=sua_chave_aqui
   \`\`\`
5. Conecte seu dispositivo Android ou inicie um Emulador com Android 14/15.
6. Clique em **Run 'app'** (Shift + F10).

## Funcionalidades Incluídas:
- Conversação por voz (SpeechRecognizer e TextToSpeech pt-BR calibrado)
- Conversação por texto
- Cérebro Gemini 3.8 Flash com pesquisa no Google Search
- Motor local offline para respostas sem internet e comandos de hardware
- Permissões transparentes (Câmera, Áudio, Notificações)
- Biometria para transações financeiras / ações de alto impacto
- Central Veicular Rick Auto com velocímetro e telemetria
- Sincronização Mesh Nearby Connections entre dispositivos
`
      );

      // Root Gradle files
      zip.file(
        'settings.gradle.kts',
        `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "RickAssistant"
include(":app")
`
      );

      zip.file(
        'build.gradle.kts',
        `plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
`
      );

      // Add all Kotlin codebase files into their correct directory structure
      for (const item of KOTLIN_CODEBASE) {
        zip.file(item.path, item.code);
      }

      // Generate the ZIP blob
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'rick-assistente-android-studio.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setIsGenerating(false);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Erro ao gerar ZIP do projeto:', err);
      setIsGenerating(false);
      alert('Falha ao empacotar arquivos. Tente novamente.');
    }
  };

  // Direct PWA Install prompt trigger
  const handleInstallAppPWA = async () => {
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      const choiceResult = await deferredInstallPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        console.log('Usuário aceitou a instalação do Rick PWA');
      }
      setDeferredInstallPrompt(null);
    } else {
      alert(
        'Para instalar o Rick no seu celular Android:\n\n1. Toque nos 3 pontinhos do Chrome ou navegador.\n2. Selecione "Adicionar à tela inicial" ou "Instalar aplicativo".\n3. O Rick funcionará como app nativo com modo offline e tela cheia!'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-cyan-500/40 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative overflow-hidden">
        {/* Glow corner */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-cyan-500/20 rounded-full blur-2xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between border-b border-cyan-950 pb-4 mb-5">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-cyan-950 border border-cyan-500/40 rounded-2xl text-cyan-400">
              <Download className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-100 font-mono tracking-wide">
                CENTRAL DE DOWNLOAD DO RICK
              </h3>
              <p className="text-xs text-slate-400">
                Instale no seu Android ou baixe o código fonte nativo
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Options Grid */}
        <div className="space-y-3.5 max-h-[75vh] overflow-y-auto pr-1">
          {/* Option 1: Full App Project ZIP (Server, Frontend, PWA, Configs, Everything) */}
          <div className="p-4 bg-gradient-to-br from-cyan-950/60 to-slate-950 border-2 border-cyan-500/60 rounded-2xl space-y-2.5 shadow-xl relative">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-cyan-500/20 text-cyan-300 rounded-xl border border-cyan-500/40">
                  <FolderArchive className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-mono flex items-center gap-1.5">
                    Projeto Atual Completo (.ZIP)
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  </h4>
                  <p className="text-[11px] text-cyan-200/80">
                    Frontend React + Servidor Express + PWA + Módulos Kotlin
                  </p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-cyan-900 text-cyan-300 border border-cyan-400/50 uppercase tracking-wider">
                COMPLETO
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Baixa todo o repositório atual em um arquivo <code>.zip</code>: código-fonte completo (React 19, TypeScript, Tailwind, servidor Express com Gemini, Service Worker PWA, ícones e código nativo).
            </p>

            <button
              onClick={handleDownloadFullAppZip}
              disabled={isDownloadingFull}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-50 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-cyan-950 transition cursor-pointer"
            >
              {isDownloadingFull ? (
                <>
                  <span className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                  Compactando e Baixando Projeto...
                </>
              ) : fullZipSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  Download Iniciado com Sucesso!
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-cyan-200" />
                  Baixar Projeto Atual Completo (.zip)
                </>
              )}
            </button>
          </div>

          {/* Option 2: Install PWA on Device */}
          <div className="p-4 bg-gradient-to-br from-slate-950 to-emerald-950/30 border border-emerald-500/30 rounded-2xl space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-emerald-900/40 text-emerald-400 rounded-xl">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-100 font-mono">
                    Instalar Aplicativo no Android
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Instalação direta com suporte offline completo (PWA Nativo)
                  </p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                DISPOSITIVO
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Instale o Rick direto no seu celular com ícone na tela inicial, execução em tela cheia,
              acesso à câmera, voz e funcionamento 100% offline via Service Worker.
            </p>

            <button
              onClick={handleInstallAppPWA}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition cursor-pointer"
            >
              <HardDriveDownload className="w-4 h-4" />
              Instalar Rick no Aparelho
            </button>
          </div>

          {/* Option 3: Download Full Kotlin/Jetpack Compose Source ZIP */}
          <div className="p-4 bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-slate-800 text-amber-400 rounded-xl">
                  <FileArchive className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-100 font-mono">
                    Código Fonte Android Nativo Kotlin (ZIP)
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Projeto Android Studio puro em Kotlin & Jetpack Compose (SDK 35)
                  </p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                ANDROID PURO
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Baixe todos os arquivos prontos para abrir no Android Studio: UI Compose, ViewModel,
              VoiceEngine nativo, Bridge de Hardware, HUD Veicular e Mesh Nearby Connections.
            </p>

            <button
              onClick={handleDownloadAndroidZip}
              disabled={isGenerating}
              className="w-full py-2.5 px-4 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-cyan-950 transition cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <span className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                  Gerando pacote ZIP...
                </>
              ) : downloadSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  Download Concluído!
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Baixar Projeto Completo (.zip)
                </>
              )}
            </button>
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            100% Autêntico e Seguro
          </span>
          <span>v1.0.0-beta</span>
        </div>
      </div>
    </div>
  );
};
