import React, { useState } from 'react';
import { Code2, Copy, Check, FileCode, Layers, Download } from 'lucide-react';

export interface KotlinFile {
  name: string;
  category: 'UI' | 'ViewModel' | 'Gemini' | 'Voice' | 'Bridge' | 'Config';
  path: string;
  code: string;
}

export const KOTLIN_CODEBASE: KotlinFile[] = [
  {
    name: 'MainActivity.kt',
    category: 'UI',
    path: 'app/src/main/java/com/rick/assistant/MainActivity.kt',
    code: `package com.rick.assistant

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.rick.assistant.ui.RickScreen
import com.rick.assistant.ui.theme.RickTheme
import com.rick.assistant.viewmodel.RickViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: RickViewModel by viewModels()

    // Transparent Android runtime permissions handler
    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
        viewModel.onPermissionsUpdated(recordAudioGranted, cameraGranted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request initial audio & camera permissions transparently
        requestPermissionsLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.POST_NOTIFICATIONS
            )
        )

        setContent {
            RickTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RickScreen(viewModel = viewModel)
                }
            }
        }
    }
}`,
  },
  {
    name: 'RickScreen.kt',
    category: 'UI',
    path: 'app/src/main/java/com/rick/assistant/ui/RickScreen.kt',
    code: `package com.rick.assistant.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rick.assistant.viewmodel.RickViewModel
import com.rick.assistant.viewmodel.VoiceState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RickScreen(viewModel: RickViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    var inputText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Rick — Assistente Beta", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF090D16)
                ),
                actions = {
                    IconButton(onClick = { viewModel.toggleTorch() }) {
                        Icon(Icons.Default.FlashlightOn, contentDescription = "Lanterna", tint = Color.Cyan)
                    }
                    IconButton(onClick = { viewModel.openMemoryVault() }) {
                        Icon(Icons.Default.Storage, contentDescription = "Memórias", tint = Color.Green)
                    }
                }
            )
        },
        containerColor = Color(0xFF05080F)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Messages List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                reverseLayout = true
            ) {
                items(uiState.messages.reversed()) { msg ->
                    ChatBubble(message = msg)
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            // Futuristic Rick Interactive Voice Core
            RickVoiceOrb(
                voiceState = uiState.voiceState,
                onOrbClick = { viewModel.onVoiceOrbToggled() }
            )

            // Input Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Fale ou digite para o Rick...") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF131B2E),
                        unfocusedContainerColor = Color(0xFF131B2E),
                        focusedTextColor = Color.White
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00ADB5))
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Color.White)
                }
            }
        }
    }
}`,
  },
  {
    name: 'RickViewModel.kt',
    category: 'ViewModel',
    path: 'app/src/main/java/com/rick/assistant/viewmodel/RickViewModel.kt',
    code: `package com.rick.assistant.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rick.assistant.data.GeminiBrainClient
import com.rick.assistant.data.MemoryRepository
import com.rick.assistant.hardware.AndroidToolsBridge
import com.rick.assistant.voice.RickVoiceSynthesizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class VoiceState { IDLE, LISTENING, THINKING, SPEAKING }

data class Message(
    val id: String,
    val sender: String,
    val text: String,
    val searchSources: List<String> = emptyList()
)

data class RickUiState(
    val messages: List<Message> = emptyList(),
    val voiceState: VoiceState = VoiceState.IDLE,
    val isTorchOn: Boolean = false,
    val batteryPct: Int = 100
)

class RickViewModel(
    private val geminiClient: GeminiBrainClient,
    private val memoryRepo: MemoryRepository,
    private val voiceSynthesizer: RickVoiceSynthesizer,
    private val androidBridge: AndroidToolsBridge
) : ViewModel() {

    private val _uiState = MutableStateFlow(RickUiState())
    val uiState: StateFlow<RickUiState> = _uiState.asStateFlow()

    fun sendMessage(prompt: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(voiceState = VoiceState.THINKING)
            
            // Fetch explicit authorized memories to inject into prompt
            val userMemories = memoryRepo.getAllAuthorizedMemories()
            
            // Query Gemini Brain with Google Search grounding enabled
            val result = geminiClient.queryRickBrain(
                userPrompt = prompt,
                memories = userMemories,
                isCarMode = false
            )

            // Speak response with original Brazilian male raspy voice
            voiceSynthesizer.speak(result.cleanText) {
                _uiState.value = _uiState.value.copy(voiceState = VoiceState.IDLE)
            }
        }
    }

    fun toggleTorch() {
        val newState = !_uiState.value.isTorchOn
        androidBridge.setFlashlight(newState)
        _uiState.value = _uiState.value.copy(isTorchOn = newState)
    }

    fun onVoiceOrbToggled() {
        if (_uiState.value.voiceState == VoiceState.LISTENING) {
            voiceSynthesizer.stopListening()
            _uiState.value = _uiState.value.copy(voiceState = VoiceState.IDLE)
        } else {
            _uiState.value = _uiState.value.copy(voiceState = VoiceState.LISTENING)
            voiceSynthesizer.startListening { transcribed ->
                sendMessage(transcribed)
            }
        }
    }
}`,
  },
  {
    name: 'GeminiBrainClient.kt',
    category: 'Gemini',
    path: 'app/src/main/java/com/rick/assistant/data/GeminiBrainClient.kt',
    code: `package com.rick.assistant.data

import io.ktor.client.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import kotlinx.serialization.json.*

class GeminiBrainClient(private val httpClient: HttpClient, private val apiKey: String) {

    private val RICK_SYSTEM_PROMPT = """
        Você é o 'Rick — Assistente Inteligente Beta'.
        PERSONALIDADE:
        - Curioso, inteligente, respostas rápidas e naturais em pt-BR.
        - Humor sarcástico e irreverente sem ser ofensivo.
        - Sabe quando ser sério (segurança, finanças, emergências).
        - NUNCA finja ter realizado uma ação que não realizou.
        - Identifique fontes de pesquisa na web e distinga de conhecimento próprio.
        - Salve apenas memórias explicitamente autorizadas com [SALVAR_MEMORIA: texto].
    """.trimIndent()

    suspend fun queryRickBrain(
        userPrompt: String,
        memories: List<String>,
        isCarMode: Boolean
    ): RickBrainResponse {
        val payload = buildJsonObject {
            put("model", "gemini-3.8-flash")
            putJsonObject("systemInstruction") {
                put("text", RICK_SYSTEM_PROMPT + "\\n[MEMÓRIAS DO USUÁRIO]: " + memories.joinToString("; "))
            }
            putJsonArray("tools") {
                addJsonObject { putJsonObject("googleSearch") {} }
            }
        }

        val response = httpClient.post("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey") {
            contentType(ContentType.Application.Json)
            setBody(payload.toString())
        }

        return parseGeminiResponse(response.bodyAsText())
    }
}

data class RickBrainResponse(
    val cleanText: String,
    val searchSources: List<String>,
    val memoryToSave: String?,
    val commands: List<String>
)`,
  },
  {
    name: 'RickVoiceSynthesizer.kt',
    category: 'Voice',
    path: 'app/src/main/java/com/rick/assistant/voice/RickVoiceSynthesizer.kt',
    code: `package com.rick.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

class RickVoiceSynthesizer(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(context, this)
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("pt", "BR")
            
            // Configure Rick's signature voice characteristics:
            // Adult male tone: pitch slightly lowered (0.92f)
            // Energetic, confident, fast speech rate: (1.14f)
            tts?.setPitch(0.92f)
            tts?.setSpeechRate(1.14f)

            // Select natural Brazilian Portuguese male voice if available
            val voices = tts?.voices ?: emptySet()
            val malePtBr = voices.firstOrNull { 
                it.locale == Locale("pt", "BR") && it.name.contains("male", ignoreCase = true) 
            }
            malePtBr?.let { tts?.voice = it }
        }
    }

    fun speak(text: String, onDone: () -> Unit) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "RICK_TTS_ID")
    }

    fun startListening(onResult: (String) -> Unit) {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
    }
}`,
  },
  {
    name: 'MemoryRepository.kt',
    category: 'Config',
    path: 'app/src/main/java/com/rick/assistant/data/MemoryRepository.kt',
    code: `package com.rick.assistant.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "user_memories")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val content: String,
    val category: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isUserAuthorized: Boolean = true
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM user_memories WHERE isUserAuthorized = 1 ORDER BY createdAt DESC")
    suspend fun getAllMemories(): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity)

    @Delete
    suspend fun deleteMemory(memory: MemoryEntity)

    @Query("DELETE FROM user_memories")
    suspend fun clearAll()
}

class MemoryRepository(private val dao: MemoryDao) {
    suspend fun getAllAuthorizedMemories(): List<String> {
        return dao.getAllMemories().map { it.content }
    }

    suspend fun saveMemory(content: String, category: String = "geral") {
        dao.insertMemory(
            MemoryEntity(
                id = java.util.UUID.randomUUID().toString(),
                content = content,
                category = category
            )
        )
    }
}`,
  },
  {
    name: 'AndroidToolsBridge.kt',
    category: 'Bridge',
    path: 'app/src/main/java/com/rick/assistant/hardware/AndroidToolsBridge.kt',
    code: `package com.rick.assistant.hardware

import android.content.Context
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.media.AudioManager

class AndroidToolsBridge(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // Honest execution: toggles torch and reports real failure if hardware lacks flash
    fun setFlashlight(enabled: Boolean): Boolean {
        return try {
            val cameraId = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(cameraId, enabled)
            true
        } catch (e: Exception) {
            // Rick never fakes an action
            false
        }
    }

    fun getBatteryLevel(): Int {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    fun setMediaVolume(percent: Int) {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (percent / 100f * max).toInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
    }
}`,
  },
  {
    name: 'CarMultimediaBridge.kt',
    category: 'Bridge',
    path: 'app/src/main/java/com/rick/assistant/car/CarMultimediaBridge.kt',
    code: `package com.rick.assistant.car

import androidx.car.app.CarAppService
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.model.*

/**
 * Android Auto / Car App Library Integration
 * Hands-free HUD voice assistant for vehicle head units
 */
class RickCarAppService : CarAppService() {
    override fun onCreateSession(): Session {
        return object : Session() {
            override fun onCreateScreen(intent: android.content.Intent): Screen {
                return RickCarMainScreen(carContext)
            }
        }
    }
}

class RickCarMainScreen(carContext: androidx.car.app.CarContext) : Screen(carContext) {
    override fun onGetTemplate(): Template {
        return PaneTemplate.Builder(
            Pane.Builder().apply {
                addRow(
                    Row.Builder()
                        .setTitle("Rick — Assistente Veicular")
                        .addText("Toque no microfone ou diga 'E aí Rick'")
                        .build()
                )
            }.build()
        )
        .setTitle("Rick Auto HUD")
        .setHeaderAction(Action.APP_ICON)
        .build()
    }
}`,
  },
  {
    name: 'RickOfflineBrain.kt',
    category: 'ViewModel',
    path: 'app/src/main/java/com/rick/assistant/offline/RickOfflineBrain.kt',
    code: `package com.rick.assistant.offline

import android.content.Context
import com.rick.assistant.data.MemoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Motor Neural Nativo Offline do Rick (Android On-Device / Edge Computing)
 * Processa intenções de hardware, memórias autorizadas, biometria e diálogo
 * mesmo sem conexão com a internet ou em modo avião.
 */
class RickOfflineBrain(
    private val context: Context,
    private val memoryRepo: MemoryRepository
) {
    suspend fun processOffline(
        prompt: String,
        batteryPct: Int,
        isTorchOn: Boolean
    ): OfflineResult = withContext(Dispatchers.Default) {
        val lower = prompt.trim().lowercase()

        when {
            lower.contains("lanterna") && (lower.contains("liga") || lower.contains("acende")) -> {
                OfflineResult(
                    text = "Lanterna ativada em modo offline pelo motor nativo!",
                    command = "lanterna_on"
                )
            }
            lower.contains("lanterna") && (lower.contains("desliga") || lower.contains("apaga")) -> {
                OfflineResult(
                    text = "Lanterna desligada. Economizando bateria offline.",
                    command = "lanterna_off"
                )
            }
            lower.contains("pix") || lower.contains("transfer") || lower.contains("banco") -> {
                OfflineResult(
                    text = "Operação sensível detectada! Exigindo autenticação biométrica local no Android Biometrics Prompt.",
                    needsBiometrics = "Operação Financeira Local"
                )
            }
            lower.contains("lembre-se") || lower.contains("guarde") -> {
                val fact = prompt.replace(Regex("(?i)^(rick,?|por favor,?|lembre-se que|guarde que|\\\\s+)+"), "").trim()
                memoryRepo.saveMemory(fact, "pessoal")
                OfflineResult(
                    text = "Fato gravado no Room Database local offline com sucesso: \\"$fact\\"",
                    savedMemory = fact
                )
            }
            lower.contains("bateria") -> {
                OfflineResult(
                    text = "Telemetria local offline: Bateria em $batteryPct%."
                )
            }
            lower.contains("modo carro") || lower.contains("direção") -> {
                OfflineResult(
                    text = "Iniciando HUD Veicular Offline!",
                    command = "modo_carro"
                )
            }
            else -> {
                OfflineResult(
                    text = "Comando processado localmente no Android sem conexão com a internet. Resposta instantânea e privada!"
                )
            }
        }
    }
}

data class OfflineResult(
    val text: String,
    val command: String? = null,
    val savedMemory: String? = null,
    val needsBiometrics: String? = null
)`,
  },
  {
    name: 'DeviceSyncService.kt',
    category: 'Bridge',
    path: 'app/src/main/java/com/rick/assistant/mesh/DeviceSyncService.kt',
    code: `package com.rick.assistant.mesh

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*

/**
 * Android Nearby Connections API
 * P2P Mesh communication for Rick between Tablets, Wearables and Car Units
 */
class DeviceSyncService(private val context: Context) {

    private val SERVICE_ID = "com.rick.assistant.mesh"
    private val client = Nearby.getConnectionsClient(context)

    fun startAdvertising() {
        val advertisingOptions = AdvertisingOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()

        client.startAdvertising(
            "Rick-Android-Node",
            SERVICE_ID,
            connectionLifecycleCallback,
            advertisingOptions
        )
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            // Auto accept authenticated device mesh pairing
            client.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {}
        override fun onDisconnected(endpointId: String) {}
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val receivedBytes = payload.asBytes()
            // Process synchronized command from nearby Android device
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }
}`,
  },
  {
    name: 'build.gradle.kts',
    category: 'Config',
    path: 'app/build.gradle.kts',
    code: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.rick.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rick.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0-beta"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    // Jetpack Compose & Material 3
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)

    // Android Biometrics for High Impact Operations
    implementation("androidx.biometric:biometric:1.2.0-alpha05")

    // Room Database for Controlled User Memory
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")

    // Android Auto / Car App Library
    implementation("androidx.car.app:app:1.4.0")

    // Google Play Services Nearby Connections for Device Mesh
    implementation("com.google.android.gms:play-services-nearby:19.3.0")

    // Ktor Client for Gemini API
    implementation("io.ktor:ktor-client-android:2.3.12")
    implementation("io.ktor:ktor-client-content-negotiation:2.3.12")
}`,
  },
];

interface KotlinCodeViewerProps {
  onOpenDownloadModal?: () => void;
}

export const KotlinCodeViewer: React.FC<KotlinCodeViewerProps> = ({ onOpenDownloadModal }) => {
  const [selectedFile, setSelectedFile] = useState<KotlinFile>(KOTLIN_CODEBASE[0]);
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadAll = () => {
    if (onOpenDownloadModal) {
      onOpenDownloadModal();
      return;
    }
    const blob = new Blob(
      [
        KOTLIN_CODEBASE.map(
          (f) => `// ==========================================\n// FILE: ${f.path}\n// ==========================================\n\n${f.code}\n\n`
        ).join('\n')
      ],
      { type: 'text/plain;charset=utf-8' }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'rick-android-native-codebase.kt';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 bg-slate-950 p-4 md:p-6 overflow-hidden flex flex-col space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-cyan-900/40 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-cyan-950 border border-cyan-500/40 rounded-xl text-cyan-400">
            <Code2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100 font-mono tracking-wide">
                ARQUITETURA NATIVA KOTLIN & JETPACK COMPOSE
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-400 border border-cyan-500/30">
                ANDROID STUDIO READY
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Código fonte modular pronto para compilar no Android SDK 35
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copiado!' : 'Copiar Arquivo'}
          </button>
          <button
            onClick={handleDownloadAll}
            className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition shadow-lg shadow-cyan-950"
          >
            <Download className="w-4 h-4" />
            Baixar Projeto Completo
          </button>
        </div>
      </div>

      {/* Main split: File tabs list & Code editor view */}
      <div className="flex-1 flex flex-col md:flex-row gap-4 overflow-hidden min-h-0">
        {/* File Navigator */}
        <div className="w-full md:w-64 bg-slate-900/90 border border-slate-800 rounded-2xl p-3 overflow-y-auto space-y-1.5 shrink-0">
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400 px-2 block mb-2">
            Módulos do Projeto ({KOTLIN_CODEBASE.length})
          </span>
          {KOTLIN_CODEBASE.map((file) => {
            const isSelected = selectedFile.name === file.name;
            return (
              <button
                key={file.name}
                onClick={() => setSelectedFile(file)}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 font-semibold'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <div className="flex items-center space-x-2 truncate">
                  <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="truncate">{file.name}</span>
                </div>
                <span className="text-[9px] font-mono px-1 py-0.5 rounded bg-slate-800 text-slate-400 shrink-0">
                  {file.category}
                </span>
              </button>
            );
          })}
        </div>

        {/* Code Content View */}
        <div className="flex-1 bg-slate-950 border border-cyan-500/30 rounded-2xl flex flex-col overflow-hidden min-h-0">
          {/* File path top bar */}
          <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
            <span className="truncate text-cyan-300">{selectedFile.path}</span>
            <span className="text-[10px] uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              Kotlin / Jetpack Compose
            </span>
          </div>

          {/* Syntax display */}
          <div className="flex-1 p-4 overflow-auto font-mono text-xs text-slate-200 leading-relaxed bg-[#060913] select-text">
            <pre>
              <code>{selectedFile.code}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
