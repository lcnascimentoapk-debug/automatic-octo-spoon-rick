import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Send,
  Camera,
  Database,
  Car,
  Code2,
  Share2,
  SlidersHorizontal,
  Volume2,
  VolumeX,
  Globe,
  ExternalLink,
  Shield,
  ShieldCheck,
  AlertTriangle,
  Play,
  Square,
  Sparkles,
  Smartphone,
  Trash2,
  WifiOff,
  Wifi,
  HardDrive,
  Download,
} from 'lucide-react';

import { ChatMessage, MemoryItem, ConnectedDevice, SystemState } from './types/rick';
import { rickVoice } from './services/RickVoiceEngine';
import { androidBridge } from './services/AndroidBridgeService';
import { rickOfflineBrain } from './services/RickOfflineBrain';
import { OfflineStorageManager } from './services/OfflineStorageManager';

import { AndroidStatusBar } from './components/AndroidStatusBar';
import { RickOrb } from './components/RickOrb';
import { CameraVisionModal } from './components/CameraVisionModal';
import { MemoryVaultModal } from './components/MemoryVaultModal';
import { BiometricAuthModal } from './components/BiometricAuthModal';
import { CarMultimediaHUD } from './components/CarMultimediaHUD';
import { DeviceMeshPanel } from './components/DeviceMeshPanel';
import { AndroidToolsDrawer } from './components/AndroidToolsDrawer';
import { KotlinCodeViewer } from './components/KotlinCodeViewer';
import { DownloadProjectModal } from './components/DownloadProjectModal';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { VoiceCustomizerModal } from './components/VoiceCustomizerModal';
import { VoiceSettings } from './types/rick';
import { VoiceProfileManager } from './services/VoiceProfileManager';

const DEFAULT_MEMORIES: MemoryItem[] = [
  {
    id: 'mem-1',
    content: 'Nome do usuário é Lucas e prefere respostas rápidas e bem-humoradas.',
    createdAt: 'Hoje',
    category: 'pessoal',
    confirmedByUser: true,
  },
  {
    id: 'mem-2',
    content: 'Veículo principal: Honda Civic modelo 2024.',
    createdAt: 'Ontem',
    category: 'veiculo',
    confirmedByUser: true,
  },
];

const DEFAULT_WELCOME_MESSAGE: ChatMessage = {
  id: 'msg-welcome',
  role: 'assistant',
  text: 'E aí! Eu sou o Rick — seu assistente inteligente beta. Sim, eu tenho humor afiado e sarcasmo calibrado, mas quando o assunto for sério ou de segurança, eu sou 100% profissional. O que manda hoje? Estou equipado com Modo Offline Completo: opero sem internet na velocidade da luz e sincronizo quando a rede voltar!',
  timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
};

export default function App() {
  // Navigation & Mode
  const [deviceMode, setDeviceMode] = useState<SystemState['deviceMode']>('phone');

  // Assistant State
  const [voiceState, setVoiceState] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [inputText, setInputText] = useState<string>('');
  const [autoSpeak, setAutoSpeak] = useState<boolean>(true);
  const [useSearch, setUseSearch] = useState<boolean>(true);

  // Modals
  const [isCameraOpen, setIsCameraOpen] = useState<boolean>(false);
  const [isMemoryOpen, setIsMemoryOpen] = useState<boolean>(false);
  const [isToolsOpen, setIsToolsOpen] = useState<boolean>(false);
  const [isDownloadOpen, setIsDownloadOpen] = useState<boolean>(false);
  const [isInstallOpen, setIsInstallOpen] = useState<boolean>(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState<boolean>(false);
  const [deferredInstallPrompt, setDeferredInstallPrompt] = useState<any>(null);
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>(() =>
    VoiceProfileManager.loadSettings()
  );
  const [biometricPending, setBiometricPending] = useState<{
    reason: string;
    action: () => void;
  } | null>(null);

  // Hardware / System State & Offline Detection
  const initialForceOffline = OfflineStorageManager.getForceOffline();
  const [isBrowserOffline, setIsBrowserOffline] = useState<boolean>(
    typeof navigator !== 'undefined' ? !navigator.onLine : false
  );
  const [forceOffline, setForceOffline] = useState<boolean>(initialForceOffline);

  const isEffectiveOffline = isBrowserOffline || forceOffline;

  const [systemState, setSystemState] = useState<SystemState>({
    battery: 89,
    isCharging: false,
    isTorchOn: false,
    volume: 75,
    notificationsEnabled: false,
    cameraPermission: 'prompt',
    micPermission: 'prompt',
    deviceMode: 'phone',
    isOffline: isEffectiveOffline,
    forceOfflineMode: forceOffline,
  });

  // User Controlled Memories (Loaded from Local Storage for offline persistence)
  const [memories, setMemories] = useState<MemoryItem[]>(() =>
    OfflineStorageManager.loadMemories(DEFAULT_MEMORIES)
  );

  // Mesh Connected Devices
  const [devices, setDevices] = useState<ConnectedDevice[]>(() =>
    OfflineStorageManager.loadDevices(androidBridge.getDefaultMeshDevices())
  );

  // Messages Feed (Loaded from Local Storage for offline persistence)
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    OfflineStorageManager.loadMessages([DEFAULT_WELCOME_MESSAGE])
  );

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, voiceState]);

  // Sync state changes to localStorage
  useEffect(() => {
    OfflineStorageManager.saveMessages(messages);
  }, [messages]);

  useEffect(() => {
    OfflineStorageManager.saveMemories(memories);
  }, [memories]);

  useEffect(() => {
    OfflineStorageManager.saveDevices(devices);
  }, [devices]);

  // Online / Offline listener
  useEffect(() => {
    const handleOnline = () => {
      setIsBrowserOffline(false);
      setSystemState((prev) => ({ ...prev, isOffline: forceOffline ? true : false }));
    };
    const handleOffline = () => {
      setIsBrowserOffline(true);
      setSystemState((prev) => ({ ...prev, isOffline: true }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Listen for native Android PWA install event
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredInstallPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, [forceOffline]);

  // Keep systemState in sync with effective offline status
  useEffect(() => {
    setSystemState((prev) => ({
      ...prev,
      isOffline: isEffectiveOffline,
      forceOfflineMode: forceOffline,
      deviceMode: deviceMode,
    }));
  }, [isEffectiveOffline, forceOffline, deviceMode]);

  // Initialize Battery API & Voice Engine callbacks
  useEffect(() => {
    androidBridge.initBattery((battery, isCharging) => {
      setSystemState((prev) => ({ ...prev, battery, isCharging }));
    });

    rickVoice.setCallbacks({
      onListeningChange: (isListening) => {
        setVoiceState((prev) => {
          if (isListening) return 'listening';
          if (prev === 'listening') return 'idle';
          return prev;
        });
      },
      onSpeakingChange: (isSpeaking) => {
        setVoiceState((prev) => {
          if (isSpeaking) return 'speaking';
          if (prev === 'speaking') return 'idle';
          return prev;
        });
      },
    });
  }, []);

  // Voice Orb click handler
  const handleToggleVoice = () => {
    if (voiceState === 'listening') {
      rickVoice.stopListening();
      setVoiceState('idle');
    } else if (voiceState === 'speaking') {
      rickVoice.stopSpeaking();
      setVoiceState('idle');
    } else {
      rickVoice.startListening((transcription) => {
        if (transcription.trim()) {
          handleSendMessage(transcription.trim());
        }
      });
    }
  };

  // Toggle offline mode master switch
  const handleToggleOfflineMode = () => {
    const nextState = !forceOffline;
    setForceOffline(nextState);
    OfflineStorageManager.setForceOffline(nextState);

    const bannerMsg: ChatMessage = {
      id: 'msg-mode-switch-' + Date.now(),
      role: 'assistant',
      text: nextState
        ? 'Modo Offline Forçado ATIVADO! Desconectei totalmente do servidor externo. Estou rodando 100% no seu dispositivo com o motor local do Rick. Zero latência, máxima privacidade!'
        : 'Modo Offline Forçado DESATIVADO. Quando houver sinal de internet, voltarei a consultar o Gemini Brain e o Google Search.',
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, bannerMsg]);
    if (autoSpeak) {
      rickVoice.speak(bannerMsg.text);
    }
  };

  // Clear local cache
  const handleClearLocalCache = () => {
    if (confirm('Deseja limpar todo o histórico e cache local de mensagens no seu dispositivo?')) {
      setMessages([DEFAULT_WELCOME_MESSAGE]);
      OfflineStorageManager.saveMessages([DEFAULT_WELCOME_MESSAGE]);
    }
  };

  // Main chat message submission with full offline support
  const handleSendMessage = async (
    textToSend: string,
    capturedImage?: { base64: string; mimeType: string }
  ) => {
    if (!textToSend && !capturedImage) return;

    // Check for explicit user request to alter voice, clone voice, download or install the app
    const lowerText = textToSend.toLowerCase();
    if (
      lowerText.includes('mudar voz') ||
      lowerText.includes('alterar voz') ||
      lowerText.includes('trocar voz') ||
      lowerText.includes('clonar voz') ||
      lowerText.includes('clone de voz') ||
      lowerText.includes('amostra de voz') ||
      lowerText.includes('escutar uma amostra') ||
      lowerText.includes('personalizar voz') ||
      lowerText.includes('falar com essa voz') ||
      lowerText.includes('síntese de voz') ||
      lowerText.includes('voz personalizada')
    ) {
      setIsVoiceModalOpen(true);
    } else if (
      lowerText.includes('instalar') ||
      lowerText.includes('instala') ||
      lowerText.includes('tela inicial') ||
      lowerText.includes('pwa') ||
      lowerText.includes('no android') ||
      lowerText.includes('no celular')
    ) {
      setIsInstallOpen(true);
    } else if (
      lowerText.includes('download') ||
      lowerText.includes('baixar') ||
      lowerText.includes('apk') ||
      lowerText.includes('zip') ||
      lowerText.includes('código fonte') ||
      lowerText.includes('codigo fonte')
    ) {
      setIsDownloadOpen(true);
    }

    // Create user message
    const userMsg: ChatMessage = {
      id: 'msg-' + Date.now(),
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      image: capturedImage
        ? {
            previewUrl: `data:${capturedImage.mimeType};base64,${capturedImage.base64}`,
            mimeType: capturedImage.mimeType,
          }
        : undefined,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setVoiceState('thinking');

    // IF OFFLINE: Process immediately via client-side RickOfflineBrain
    if (isEffectiveOffline) {
      setTimeout(() => {
        const offlineResult = rickOfflineBrain.processOffline(
          textToSend,
          memories,
          systemState,
          !!capturedImage
        );

        // Check if Rick saved a user-authorized memory
        let savedMemoryText: string | null = null;
        if (offlineResult.newMemory) {
          const newMem: MemoryItem = {
            id: 'mem-' + Date.now(),
            content: offlineResult.newMemory,
            createdAt: 'Agora (Offline)',
            category: 'pessoal',
            confirmedByUser: true,
          };
          setMemories((prev) => [...prev, newMem]);
          savedMemoryText = offlineResult.newMemory;
        }

        // Check if biometrics is needed
        if (offlineResult.needsBiometrics) {
          setBiometricPending({
            reason: offlineResult.needsBiometrics,
            action: () => {
              executeSystemCommands(offlineResult.commands);
            },
          });
        } else {
          executeSystemCommands(offlineResult.commands);
        }

        const assistantMsg: ChatMessage = {
          id: 'msg-' + Date.now() + '-rick',
          role: 'assistant',
          text: offlineResult.text,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          commands: offlineResult.commands,
          newMemory: savedMemoryText,
          needsBiometrics: offlineResult.needsBiometrics,
        };

        setMessages((prev) => [...prev, assistantMsg]);

        if (autoSpeak && offlineResult.text) {
          setVoiceState('speaking');
          rickVoice.speak(offlineResult.text, undefined, () => {
            setVoiceState('idle');
          });
        } else {
          setVoiceState('idle');
        }
      }, 200);

      return;
    }

    // IF ONLINE: Try backend API, with fallback to local brain on network error
    try {
      const response = await fetch('/api/rick/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: messages.slice(-6).map((m) => ({
            role: m.role,
            text: m.text,
          })),
          memories: memories.map((m) => m.content),
          context: {
            battery: systemState.battery,
            isCharging: systemState.isCharging,
            isTorchOn: systemState.isTorchOn,
            volume: systemState.volume,
            deviceMode: deviceMode,
            time: new Date().toLocaleTimeString('pt-BR'),
          },
          useSearch: useSearch,
          image: capturedImage
            ? {
                data: capturedImage.base64,
                mimeType: capturedImage.mimeType,
              }
            : null,
        }),
      });

      if (!response.ok) {
        throw new Error('Falha na comunicação com o servidor');
      }

      const data = await response.json();

      // Check if Rick wants to save a user-authorized memory
      let savedMemoryText: string | null = null;
      if (data.newMemory) {
        const newMem: MemoryItem = {
          id: 'mem-' + Date.now(),
          content: data.newMemory,
          createdAt: 'Agora',
          category: 'pessoal',
          confirmedByUser: true,
        };
        setMemories((prev) => [...prev, newMem]);
        savedMemoryText = data.newMemory;
      }

      // Check if an operation requires biometric confirmation
      if (data.needsBiometrics) {
        setBiometricPending({
          reason: data.needsBiometrics,
          action: () => {
            executeSystemCommands(data.commands || []);
          },
        });
      } else {
        // Execute system commands directly if safe
        executeSystemCommands(data.commands || []);
      }

      const assistantMsg: ChatMessage = {
        id: 'msg-' + Date.now() + '-rick',
        role: 'assistant',
        text: data.text,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        searchSources: data.searchSources,
        usedWebSearch: data.usedWebSearch,
        searchQueries: data.searchQueries,
        commands: data.commands,
        newMemory: savedMemoryText,
        needsBiometrics: data.needsBiometrics,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Speak response if autoSpeak is enabled
      if (autoSpeak && data.text) {
        setVoiceState('speaking');
        rickVoice.speak(data.text, undefined, () => {
          setVoiceState('idle');
        });
      } else {
        setVoiceState('idle');
      }
    } catch (err: any) {
      console.warn('Rede indisponível no fetch. Engatando RickOfflineBrain local:', err);

      // Automatic seamless fallback to client-side offline brain
      const offlineResult = rickOfflineBrain.processOffline(
        textToSend,
        memories,
        systemState,
        !!capturedImage
      );

      let savedMemoryText: string | null = null;
      if (offlineResult.newMemory) {
        const newMem: MemoryItem = {
          id: 'mem-' + Date.now(),
          content: offlineResult.newMemory,
          createdAt: 'Agora (Offline)',
          category: 'pessoal',
          confirmedByUser: true,
        };
        setMemories((prev) => [...prev, newMem]);
        savedMemoryText = offlineResult.newMemory;
      }

      if (offlineResult.needsBiometrics) {
        setBiometricPending({
          reason: offlineResult.needsBiometrics,
          action: () => {
            executeSystemCommands(offlineResult.commands);
          },
        });
      } else {
        executeSystemCommands(offlineResult.commands);
      }

      const assistantMsg: ChatMessage = {
        id: 'msg-' + Date.now() + '-offline-rick',
        role: 'assistant',
        text: `${offlineResult.text}\n\n*(Nota do Rick: A requisição de rede oscilou, então assumi o processamento 100% local no seu dispositivo sem travar nada!)*`,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        commands: offlineResult.commands,
        newMemory: savedMemoryText,
        needsBiometrics: offlineResult.needsBiometrics,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      if (autoSpeak && offlineResult.text) {
        setVoiceState('speaking');
        rickVoice.speak(offlineResult.text, undefined, () => {
          setVoiceState('idle');
        });
      } else {
        setVoiceState('idle');
      }
    }
  };

  // Execute native Android system commands with honest reporting
  const executeSystemCommands = async (commands: string[]) => {
    for (const cmd of commands) {
      const lower = cmd.toLowerCase();

      if (lower.includes('lanterna_on')) {
        const res = await androidBridge.toggleTorch(true);
        setSystemState((prev) => ({ ...prev, isTorchOn: res.state }));
      } else if (lower.includes('lanterna_off')) {
        const res = await androidBridge.toggleTorch(false);
        setSystemState((prev) => ({ ...prev, isTorchOn: res.state }));
      } else if (lower.includes('modo_carro')) {
        setDeviceMode('car');
      } else if (lower.includes('modo_celular')) {
        setDeviceMode('phone');
      } else if (lower.startsWith('volume')) {
        const parts = cmd.split(',');
        const val = parseInt(parts[1]?.trim() || '50', 10);
        if (!isNaN(val)) {
          setSystemState((prev) => ({ ...prev, volume: Math.min(100, Math.max(0, val)) }));
        }
      } else if (lower.startsWith('enviar_notificacao')) {
        const parts = cmd.split(',');
        const title = parts[1]?.trim() || 'Rick Assistente';
        const msg = parts[2]?.trim() || 'Lembrete executado.';
        androidBridge.sendNotification(title, msg);
      }
    }
  };

  // Hardware torch toggle from UI
  const handleToggleTorch = async () => {
    const res = await androidBridge.toggleTorch();
    setSystemState((prev) => ({ ...prev, isTorchOn: res.state }));
  };

  // Notification trigger
  const handleTriggerNotification = async () => {
    const ok = await androidBridge.sendNotification(
      'Rick — Assistente Inteligente',
      'Testando push notification nativo do Android com sucesso!'
    );
    if (!ok) {
      alert('Permissão de notificações desabilitada ou não suportada no momento.');
    }
  };

  // App launcher simulator
  const handleLaunchApp = (appName: string) => {
    alert(`[Android Launcher]: Iniciando ${appName}...`);
  };

  // Handle capture from Camera Vision Modal
  const handleCaptureImage = (base64Data: string, mimeType: string) => {
    handleSendMessage('Analise o que você vê nesta imagem capturada pela câmera do dispositivo.', {
      base64: base64Data,
      mimeType,
    });
  };

  // Add memory manually
  const handleAddMemory = (content: string, category: string = 'pessoal') => {
    const newMem: MemoryItem = {
      id: 'mem-' + Date.now(),
      content,
      createdAt: 'Agora',
      category: category as any,
      confirmedByUser: true,
    };
    setMemories((prev) => [...prev, newMem]);
  };

  // Delete single memory
  const handleDeleteMemory = (id: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== id));
  };

  // Request clear all memories (requires biometric confirmation)
  const handleRequestClearAllMemories = () => {
    setBiometricPending({
      reason: 'Apagar permanentemente todas as memórias pessoais gravadas no cofre do Rick.',
      action: () => {
        setMemories([]);
        setIsMemoryOpen(false);
      },
    });
  };

  // Send message to mesh device
  const handleSendMessageToMesh = (deviceId: string, text: string) => {
    const dev = devices.find((d) => d.id === deviceId);
    if (dev) {
      setDevices((prev) =>
        prev.map((d) =>
          d.id === deviceId ? { ...d, lastSync: 'Acabou de sincronizar' } : d
        )
      );
    }
  };

  // Last assistant text for Car HUD
  const lastRickText =
    [...messages].reverse().find((m) => m.role === 'assistant')?.text || '';

  return (
    <div className="flex flex-col h-screen w-screen bg-[#050811] text-slate-100 font-sans overflow-hidden">
      {/* Android System Status Bar */}
      <AndroidStatusBar
        battery={systemState.battery}
        isCharging={systemState.isCharging}
        isOffline={isEffectiveOffline}
        onOpenTools={() => setIsToolsOpen(true)}
        onToggleOffline={handleToggleOfflineMode}
      />

      {/* Navigation Mode Switcher Tabs */}
      <nav className="w-full bg-slate-950/90 border-b border-cyan-900/40 px-3 py-2 flex items-center justify-between overflow-x-auto z-30 select-none">
        <div className="flex items-center space-x-1 sm:space-x-2">
          <button
            onClick={() => setDeviceMode('phone')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
              deviceMode === 'phone'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span>Smartphone</span>
          </button>

          <button
            onClick={() => setDeviceMode('car')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
              deviceMode === 'car'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Car className="w-4 h-4 text-teal-400" />
            <span>Rick Auto (Central)</span>
          </button>

          <button
            onClick={() => setDeviceMode('mesh')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
              deviceMode === 'mesh'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Share2 className="w-4 h-4 text-pink-400" />
            <span>Mesh Android</span>
          </button>

          <button
            onClick={() => setDeviceMode('code')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
              deviceMode === 'code'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/50 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Code2 className="w-4 h-4 text-amber-400" />
            <span>Código Kotlin</span>
          </button>
        </div>

        {/* Quick action shortcuts */}
        <div className="flex items-center space-x-2 pl-2">
          {/* Voice Customizer & Voice Cloning Button */}
          <button
            onClick={() => setIsVoiceModalOpen(true)}
            className="px-2.5 py-1 rounded-lg border border-cyan-500/60 bg-gradient-to-r from-cyan-950/90 to-blue-950/90 hover:from-cyan-900 hover:to-blue-900 text-cyan-300 hover:text-cyan-200 text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-sm shadow-cyan-950"
            title="Alterar ou Clonar Voz do Rick (Síntese Neural / Amostra de Áudio)"
          >
            <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Voz do Rick</span>
            <span className="sm:hidden">Voz</span>
          </button>

          {/* Direct Install on Android Button */}
          <button
            onClick={() => setIsInstallOpen(true)}
            className="px-2.5 py-1 rounded-lg border border-emerald-500/60 bg-gradient-to-r from-emerald-950/90 to-teal-950/90 hover:from-emerald-900 hover:to-teal-900 text-emerald-300 hover:text-emerald-200 text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-sm shadow-emerald-950"
            title="Instalar Rick diretamente no celular Android (PWA)"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Instalar no Android</span>
            <span className="sm:hidden">Instalar</span>
          </button>

          {/* Download Center Button */}
          <button
            onClick={() => setIsDownloadOpen(true)}
            className="px-2.5 py-1 rounded-lg border border-cyan-500/50 bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 shadow-sm shadow-cyan-950"
            title="Central de Download (Instalar PWA / Baixar ZIP Android Studio)"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Download</span>
          </button>

          {/* Offline quick toggle */}
          <button
            onClick={handleToggleOfflineMode}
            className={`px-2 py-1 rounded-lg border text-xs transition cursor-pointer flex items-center gap-1 ${
              isEffectiveOffline
                ? 'bg-amber-950/80 border-amber-500/50 text-amber-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Alternar Modo Offline Completo"
          >
            {isEffectiveOffline ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden md:inline text-[11px] font-mono">Offline</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden md:inline text-[11px] font-mono">Online</span>
              </>
            )}
          </button>

          {/* Torch toggle quick indicator */}
          <button
            onClick={handleToggleTorch}
            className={`p-1.5 rounded-lg border text-xs transition cursor-pointer ${
              systemState.isTorchOn
                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Lanterna Android"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {/* Memory vault trigger */}
          <button
            onClick={() => setIsMemoryOpen(true)}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-slate-400 hover:text-cyan-300 text-xs transition flex items-center gap-1 cursor-pointer"
            title="Cofre de Memórias Pessoais"
          >
            <Database className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline font-mono text-[11px]">{memories.length}</span>
          </button>

          {/* Tools drawer trigger */}
          <button
            onClick={() => setIsToolsOpen(true)}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-slate-300 hover:text-white transition cursor-pointer"
            title="Gaveta de Ferramentas"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>
      </nav>

      {/* Main View Area based on selected mode */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {deviceMode === 'car' ? (
          <CarMultimediaHUD
            voiceState={voiceState}
            onTriggerVoice={handleToggleVoice}
            onSwitchToPhone={() => setDeviceMode('phone')}
            lastRickResponse={lastRickText}
          />
        ) : deviceMode === 'mesh' ? (
          <DeviceMeshPanel
            devices={devices}
            onSendMessageToDevice={handleSendMessageToMesh}
          />
        ) : deviceMode === 'code' ? (
          <KotlinCodeViewer onOpenDownloadModal={() => setIsDownloadOpen(true)} />
        ) : (
          /* Phone Chat & Voice Mode */
          <div className="flex-1 flex flex-col overflow-hidden max-w-4xl w-full mx-auto p-3 sm:p-4">
            {/* Offline Alert Strip when active */}
            {isEffectiveOffline && (
              <div className="mb-2 px-3 py-1.5 bg-amber-950/60 border border-amber-500/30 rounded-xl flex items-center justify-between text-xs text-amber-300 animate-in fade-in duration-200">
                <div className="flex items-center gap-2">
                  <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="font-mono text-[11px]">
                    <strong>Modo Offline Ativo:</strong> Motor local em execução. Hardware, memórias e voz funcionando 100% sem rede.
                  </span>
                </div>
                <button
                  onClick={handleToggleOfflineMode}
                  className="text-[10px] underline font-mono text-amber-200 hover:text-white cursor-pointer ml-2 shrink-0"
                >
                  {forceOffline ? 'Desativar Forçado' : 'Tentar Reconectar'}
                </button>
              </div>
            )}

            {/* Messages Scroll Area */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1 pb-4">
              {messages.map((msg) => {
                const isUser = msg.role === 'user';
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-1.5`}
                  >
                    {/* Role header and timestamp */}
                    <div className="flex items-center space-x-2 text-[10px] font-mono text-slate-400 px-1">
                      <span className={isUser ? 'text-cyan-400 font-semibold' : 'text-teal-400 font-semibold'}>
                        {isUser ? 'VOCÊ' : isEffectiveOffline ? 'RICK (OFFLINE)' : 'RICK BETA'}
                      </span>
                      <span>•</span>
                      <span>{msg.timestamp}</span>
                    </div>

                    {/* Chat Bubble */}
                    <div
                      className={`max-w-[88%] sm:max-w-[78%] rounded-2xl p-4 shadow-xl text-sm leading-relaxed ${
                        isUser
                          ? 'bg-gradient-to-r from-cyan-900/60 to-cyan-950/80 border border-cyan-500/40 text-slate-100 rounded-tr-none'
                          : 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-tl-none'
                      }`}
                    >
                      {/* Image attached if any */}
                      {msg.image && (
                        <div className="mb-2.5 rounded-xl overflow-hidden border border-cyan-500/30 max-h-56">
                          <img
                            src={msg.image.previewUrl}
                            alt="Foto enviada para análise"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}

                      {/* Text */}
                      <p className="whitespace-pre-wrap">{msg.text}</p>

                      {/* Memory saved alert badge */}
                      {msg.newMemory && (
                        <div className="mt-2.5 p-2 bg-emerald-950/70 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-1.5 font-sans">
                          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>
                            <strong>Memória pessoal autorizada:</strong> "{msg.newMemory}"
                          </span>
                        </div>
                      )}

                      {/* Biometric request banner */}
                      {msg.needsBiometrics && (
                        <div className="mt-2.5 p-2 bg-amber-950/70 border border-amber-500/40 rounded-xl text-amber-300 text-xs flex items-center gap-1.5">
                          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                          <span>
                            <strong>Operação sensível pendente:</strong> Autenticação biométrica exigida.
                          </span>
                        </div>
                      )}

                      {/* Google Search Grounding Sources */}
                      {msg.searchSources && msg.searchSources.length > 0 && (
                        <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1.5">
                          <div className="flex items-center gap-1 text-[11px] font-mono text-cyan-400 font-bold uppercase tracking-wider">
                            <Globe className="w-3.5 h-3.5" />
                            <span>Fontes verificadas na Web (Google Search):</span>
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {msg.searchSources.map((src, idx) => (
                              <a
                                key={idx}
                                href={src.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-cyan-900/60 hover:border-cyan-500/60 text-[11px] text-cyan-300 transition"
                              >
                                <span className="truncate max-w-[190px]">{src.title}</span>
                                <ExternalLink className="w-3 h-3 shrink-0 text-cyan-400" />
                              </a>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Speak button for assistant messages */}
                      {!isUser && (
                        <div className="mt-2 pt-1.5 flex items-center justify-between text-xs text-slate-500">
                          <button
                            onClick={() => rickVoice.speak(msg.text)}
                            className="inline-flex items-center gap-1 text-[11px] font-mono text-cyan-400/80 hover:text-cyan-300 transition cursor-pointer"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>Ouvir com a voz do Rick</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Central Holographic Voice Orb Area */}
            <div className="shrink-0 flex flex-col items-center justify-center py-1">
              <RickOrb state={voiceState} onClick={handleToggleVoice} size="md" />
            </div>

            {/* Bottom Controls & Input Form */}
            <div className="shrink-0 bg-slate-950/80 backdrop-blur-md border border-cyan-900/40 rounded-2xl p-2.5 shadow-2xl space-y-2">
              {/* Feature toggles bar */}
              <div className="flex items-center justify-between px-2 text-[11px] font-mono text-slate-400">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => setUseSearch(!useSearch)}
                    disabled={isEffectiveOffline}
                    className={`flex items-center gap-1 transition cursor-pointer ${
                      isEffectiveOffline
                        ? 'opacity-40 cursor-not-allowed text-slate-600'
                        : useSearch
                        ? 'text-cyan-300 font-semibold'
                        : 'text-slate-500'
                    }`}
                    title={isEffectiveOffline ? 'Indisponível no modo offline' : ''}
                  >
                    <Globe className="w-3.5 h-3.5 text-cyan-400" />
                    <span>
                      Pesquisa Web:{' '}
                      {isEffectiveOffline ? 'Offline' : useSearch ? 'Ligada' : 'Desligada'}
                    </span>
                  </button>

                  <button
                    onClick={() => setAutoSpeak(!autoSpeak)}
                    className={`flex items-center gap-1 transition cursor-pointer ${
                      autoSpeak ? 'text-emerald-300 font-semibold' : 'text-slate-500'
                    }`}
                  >
                    {autoSpeak ? (
                      <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <VolumeX className="w-3.5 h-3.5 text-slate-500" />
                    )}
                    <span>Resposta Falada: {autoSpeak ? 'Sim' : 'Não'}</span>
                  </button>
                </div>

                <span className="hidden sm:inline text-slate-500">
                  {isEffectiveOffline ? '⚡ Motor Local Rick (Offline)' : 'PT-BR • Gemini 3.8 Flash'}
                </span>
              </div>

              {/* Input text row */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (inputText.trim()) {
                    handleSendMessage(inputText.trim());
                  }
                }}
                className="flex items-center gap-2"
              >
                {/* Camera Scanner Trigger */}
                <button
                  type="button"
                  onClick={() => setIsCameraOpen(true)}
                  className="p-2.5 bg-slate-900 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 rounded-xl transition cursor-pointer"
                  title="Tirar foto para Rick analisar"
                >
                  <Camera className="w-5 h-5" />
                </button>

                {/* Text input */}
                <input
                  type="text"
                  placeholder={
                    isEffectiveOffline
                      ? 'Rick Offline: acender lanterna, guardar memória, bateria...'
                      : 'Fale ou digite sua pergunta para o Rick...'
                  }
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 focus:border-cyan-400 text-slate-100 placeholder:text-slate-500 text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none transition"
                />

                {/* Send button */}
                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="p-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white rounded-xl transition shadow-lg shadow-cyan-950 cursor-pointer"
                  title="Enviar mensagem"
                >
                  <Send className="w-5 h-5" />
                </button>
              </form>
            </div>
          </div>
        )}
      </main>

      {/* Modal 1: Camera Vision & Transparent Permission */}
      <CameraVisionModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCaptureImage={handleCaptureImage}
      />

      {/* Modal 2: User Controlled Memory Vault */}
      <MemoryVaultModal
        isOpen={isMemoryOpen}
        onClose={() => setIsMemoryOpen(false)}
        memories={memories}
        onAddMemory={handleAddMemory}
        onDeleteMemory={handleDeleteMemory}
        onRequestClearAll={handleRequestClearAllMemories}
      />

      {/* Modal 3: Android Biometric Confirmation */}
      <BiometricAuthModal
        isOpen={biometricPending !== null}
        reason={biometricPending?.reason || ''}
        onConfirm={() => {
          if (biometricPending) {
            biometricPending.action();
            setBiometricPending(null);
          }
        }}
        onCancel={() => setBiometricPending(null)}
      />

      {/* Modal 4: Download Center (Android Studio Project ZIP & PWA Install) */}
      <DownloadProjectModal
        isOpen={isDownloadOpen}
        onClose={() => setIsDownloadOpen(false)}
      />

      {/* Modal 5: Direct Android Installation & Home Screen Shortcut */}
      <AndroidInstallModal
        isOpen={isInstallOpen}
        onClose={() => setIsInstallOpen(false)}
        deferredPrompt={deferredInstallPrompt}
      />

      {/* Modal 6: Voice Customizer & Voice Cloning by Sample */}
      <VoiceCustomizerModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        voiceSettings={voiceSettings}
        onUpdateSettings={(newSettings) => setVoiceSettings(newSettings)}
      />

      {/* Drawer: Android Tools & Quick Launch */}
      <AndroidToolsDrawer
        isOpen={isToolsOpen}
        onClose={() => setIsToolsOpen(false)}
        systemState={systemState}
        onToggleTorch={handleToggleTorch}
        onChangeVolume={(vol) => setSystemState((prev) => ({ ...prev, volume: vol }))}
        onTriggerNotification={handleTriggerNotification}
        onOpenCamera={() => setIsCameraOpen(true)}
        onOpenMemoryVault={() => setIsMemoryOpen(true)}
        onSwitchMode={(mode) => setDeviceMode(mode)}
        onLaunchApp={handleLaunchApp}
        onToggleOffline={handleToggleOfflineMode}
        onClearLocalCache={handleClearLocalCache}
        onOpenDownloadModal={() => setIsDownloadOpen(true)}
        onOpenInstallModal={() => setIsInstallOpen(true)}
        onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
      />
    </div>
  );
}
