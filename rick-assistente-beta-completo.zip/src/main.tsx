import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Register Service Worker in production for Offline PWA Support
if ('serviceWorker' in navigator && !import.meta.env.DEV) {
  import('virtual:pwa-register')
    .then(({ registerSW }) => {
      registerSW({
        immediate: true,
        onNeedRefresh() {
          console.log('[Rick PWA]: Novo conteúdo disponível. Atualizando...');
        },
        onOfflineReady() {
          console.log('[Rick PWA]: Modo offline completo pronto para uso sem internet!');
        },
      });
    })
    .catch((err) => {
      console.warn('[Rick PWA]: Falha ao registrar Service Worker:', err);
    });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
